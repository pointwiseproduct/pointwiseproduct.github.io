//------���C���E�B���h�E
LRESULT CALLBACK WindowProc(
	HWND hwnd, UINT umsg, WPARAM wparam, LPARAM lparam
){
	switch(umsg){
		case WM_COMMAND:
			switch(LOWORD(wparam)){
				case SVCHECKBOX_ID:
					config.svcheck = !config.svcheck;
					break;
			}
			break;

		case WM_DESTROY:
			if(config.svcheck){
				strmorph::dic.write();
				strmorph::log.write();
			}
			PostQuitMessage(0);
			break;
	}

	return DefWindowProc(hwnd, umsg, wparam, lparam);
}

//------�G�f�B�b�g�{�b�N�X
FARPROC OrgPrc_EditBox;

LRESULT CALLBACK EditBox_WindowProc(
	HWND hwnd, UINT umsg, WPARAM wparam, LPARAM lparam
){
	static wchar_t buff[0xFF];
	switch(umsg){
		case WM_CHAR:
			if(static_cast<wchar_t>(wparam) == 13){
				GetWindowText(hwnd, buff, 0xFF);

				static const std::wstring user_(L"user > "), asrn_x(L"\nasrn > "), asrn_(L"\r\nasrn > ");
				std::wstring strbuff(buff);
				if(strbuff.size() > 0){
					std::wstring rstr(asrn(buff));

					logfile << user_ << strbuff << asrn_x << rstr << std::wstring(L"\n");

					rstr = user_ + strbuff + asrn_ + rstr;

					SetWindowTextW(hlog, rstr.c_str());
					SetWindowTextW(hwnd, L"");
					SetWindowTextW(hwnd, L"");
				}
			}

			break;
	}

	return (CallWindowProc(reinterpret_cast<WNDPROC>(OrgPrc_EditBox), hwnd, umsg, wparam, lparam)); 
}

//------�`�F�b�N�{�b�N�X
FARPROC OrgPrc_SvCheckBox;

LRESULT CALLBACK SvCheckBox_WindowProc(
	HWND hwnd, UINT umsg, WPARAM wparam, LPARAM lparam
){
	return (CallWindowProc(reinterpret_cast<WNDPROC>(OrgPrc_SvCheckBox), hwnd, umsg, wparam, lparam)); 
}
