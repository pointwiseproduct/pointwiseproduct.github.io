#ifndef __TTY_QUICK_SEARCH__
#define __TTY_QUICK_SEARCH__

#include <cstring>
#include <tty/st.hpp>
#include <tty/to_arthmetic.hpp>

namespace tty{
	template<typename T> class quick_search{
	private:
		typedef quick_search<T> this_t;

	public:
		//tablesize
		enum{ tablesize = tty::pow<2, sizeof(T) * 8>::value };

		//member
	private:
		//�e�[�u��
		struct table_t{
			int *tabledata; //�e�[�u���f�[�^

			inline table_t(int n) : tabledata(new int[n]){}

			inline ~table_t(){
				delete[] tabledata;
			}

		private:
			table_t() : tabledata(NULL){}
		};

		table_t table_a;

		const T *key;
		int key_length;

		typedef ::tty::to_arthmetic<T> t2a;
		typedef typename ::tty::to_arthmetic<T>::unsigned_type hkey_t;

		//method
	public:
		//�L�[���g���ăe�[�u�����\������
		template<typename U> void preprocess(U key, int key_length){
			int *table = table_a.tabledata;

			//fill
			std::memset(static_cast<void*>(table), 0, sizeof(int) * tablesize);

			//�n�b�V���e�[�u���ɂ��
			int t;
			for(int i = 0; i < key_length; ++i){
				t = key_length - 1 - i;
				if(!table[::tty::force_cast<const hkey_t>(key[t]) & t2a::mask])
					table[::tty::force_cast<const hkey_t>(key[t]) & t2a::mask] = key_length - i;
			}

			this->key = &key[0];
			this->key_length = key_length;
		}

		//��v�����C���f�b�N�X��Ԃ�
		template<typename U> int search(U text, int text_length){
			const T *key = this->key;
			int key_length = this->key_length;
			int *table = table_a.tabledata;

			//---�����𒲂ׂ�
			if(text_length < key_length){
				return -1;
			}else if(text_length == key_length){
				//���ʂ̑S����r�Ƃ��ď�������
				for(int i = 0; i < text_length; ++i){
					if(text[i] != key[i]){
						return -1;
					}
				}
				return 0;
			}

			//---����
			//goto�p�o�n��
			int idx = 0, ck = 0;
			int t;
			{
				search_start:;
				if(text[idx + ck] == key[ck]){
					++ck;

					if(ck == key_length){
						return idx;
					}else{
						goto search_start;
					}
				}else{
					t = (key_length + 1) - table[text[idx + key_length]];
					idx += t;

					if((idx + key_length) > text_length)
						return -1;

					ck = 0;
					goto search_start;
				}
			}
		}

		inline int operator()(const T *text, int text_length){
			return search(text, text_length);
		}

		inline quick_search() : table_a(tablesize){}

		virtual ~quick_search(){}
	};

	//�͔C��
	//�O���������Ȃ��̂ł�����̕��������ꍇ������Ɗ��҂���
	template<typename T, typename U> int easy_search(T key, int key_length, U text, int text_length){
		if(text_length < key_length){
			return -1;
		}else if(text_length == key_length){
			for(int i = 0; i < text_length; ++i){
				if(key[i] != text[i]) return -1;
			}
			return 0;
		}

		int idx = 0, ck = 0;
		{
			search:;
			if(text[idx + ck] == key[ck]){
				++ck;
				if(ck == key_length) return idx;
				goto search;
			}else{
				++idx;
				if((idx + key_length) > text_length) return -1;
				ck = 0;
				goto search;
			}
		}
	}
}

#endif // __TTY_QUICK_SEARCH__
