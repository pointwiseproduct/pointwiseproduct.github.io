#ifndef __TTY_MOVE__
#define __TTY_MOVE__

#include <cstring>
#include <boost/type_traits/add_reference.hpp>
#include <boost/type_traits/add_const.hpp>

namespace tty{
	//���������^������
	template<typename T> struct move_t{
	public:
		typedef T type;
		typedef typename boost::add_const<typename boost::add_reference<T>::type>::type const_reference;
	private:
		char data[sizeof(T)];
	public:
		inline T &get(){ return *reinterpret_cast<T*>(data); }
	};

	//�ړ�
	struct move_semantics{
		template<typename T> static move_t<T> move(typename move_t<T>::const_reference obj){
			move_t<T> r;
			std::memcpy(reinterpret_cast<void*>(r.data), reinterpret_cast<const void*>(&obj), sizeof(T));
			obj.rvalue_destruction();
			return r;
		}
	};

	template<typename T> inline static move_t<T> move(typename move_t<T>::const_reference obj){
		return move_semantics::move(obj);
	}
};

#endif // __TTY_MOVE__
