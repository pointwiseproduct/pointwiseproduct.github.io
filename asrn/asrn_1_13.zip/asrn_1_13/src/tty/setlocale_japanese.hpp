#ifndef __TTY_SETLOCALE_JAPANESE__
#define __TTY_SETLOCALE_JAPANESE__

#include <fstream>
#include <locale>

namespace tty{
	struct __tty_setlocale_japanese_type{
		inline __tty_setlocale_japanese_type(){
			::std::wcout.imbue(std::locale("japanese"));
			::std::wcin.imbue(std::locale("japanese"));
		}
	};

	namespace{
		__tty_setlocale_japanese_type __tty_setlocale_japanese_type;
	}

	class wfstream : public ::std::wfstream{
	public:
		inline wfstream(const wchar_t *a) : ::std::wfstream(a){
			this->imbue(std::locale("japanese"));
		}

		template<typename T> inline wfstream(const wchar_t *a, T b) : ::std::wfstream(a, b){
			this->imbue(std::locale("japanese"));
		}
	};
}

#endif // __TTY_SETLOCALE_JAPANESE__
