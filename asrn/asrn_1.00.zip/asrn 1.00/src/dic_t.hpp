#include <vector>
#include <deque>
#include <map>
#include <set>
#include <algorithm>
#include <fstream>
#include <cstring>
#include <stdlib.h>
#include <conio.h>
#include <boost/pool/object_pool.hpp>
#include <boost/preprocessor/repeat.hpp>
#include <boost/preprocessor/punctuation/comma_if.hpp>
#include <tty/st.hpp>
#include <tty/lcsubsequence.hpp>
#include <tty/setlocale_japanese.hpp>
#include <tty/rope_array.hpp>
#include <tty/fldata.hpp>
#include <tty/move.hpp>
#include <tty/bmp.hpp>

namespace strmorph{
	//�`�ԑf��͂��ꂽ�P��̗�
	//key    -> �`�ԑf��������Ɉʒu����C���f�b�N�X
	//mapped -> idmap�̃L�[
	typedef std::map<int, int> morph_sequence_container_t;
	//�������POD
	struct morph_sequence_t{
		friend tty::move_semantics;
		int length;
		int *data;
		bool uf;

	private:
		void rvalue_destruction(){
			length = 0;
			data = NULL;
			uf = false;
		}
	};
	//������͔�POD
	class morph_sequence_ht{
		friend tty::move_semantics;
		int length_;
		int *data_;
		bool uf_;

		void rvalue_destruction(){
			length_ = 0;
			data_ = NULL;
		}

	public:
		int length() const{ return length_; }
		const int *data() const{ return data_; }
		bool uf() const{ return uf_; }

		morph_sequence_ht() : length_(0), data_(NULL), uf_(false){}
		morph_sequence_ht(int length_a, int *data_a) : length_(length_a), data_(data_a), uf_(false){}

		morph_sequence_ht(const morph_sequence_ht &a) : length_(a.length_), data_(new int[length_]), uf_(false){
			std::memcpy(
				reinterpret_cast<void*>(data_),
				reinterpret_cast<const void*>(a.data_),
				sizeof(int) * length_
			);
		}

		morph_sequence_ht(tty::move_t<morph_sequence_t> &m) :
			length_(m.get().length),
			data_(m.get().data),
			uf_(m.get().uf)
		{}

		morph_sequence_ht(tty::move_t<morph_sequence_ht> &m) :
			length_(m.get().length_),
			data_(m.get().data_),
			uf_(m.get().uf_)
		{}

		~morph_sequence_ht(){
			delete[] data_;
		}
	};

	//�R���e�i��POD�^�ɕϊ�����
	//morph_sequence_t::data�͗vdelete
	morph_sequence_t morph_sequence_container2pod(const morph_sequence_container_t &a){
		morph_sequence_t r;
		r.length = static_cast<int>(a.size());
		r.data = new int[r.length];

		int i = 0;
		for(
			morph_sequence_container_t::const_iterator it = a.begin(), end = a.end();
			it != end;
			++i, ++it
		){
			r.data[i] = it->second;
		}

		return r;
	}

	//����
	class dic_t{
		//------ �f�[�^�^�Ȃ�
		//       public private����

		//���k���ꂽ�f�[�^�̓���^
	private:
		struct compressed_data_t{
			int data_length; //�o�C�g�P�ʂ̒���
			tty::fldata::data_t data;
		};

		//�f�[�^�^
	public:
		struct data_t{
			/*
				--- �t�H�[�}�b�g
				[fldata]	id
				[fldata]	value

				[fldata]	transitionelem_num �J�ڐ悪����邩
				[�ȉ��̂��̂�transitionelem_num�̐��������݂���]
					[fldata]	�J�ڐ�id
					[fldata]	�X�R�A

				[fldata]	reverse_transitionelem_num ��J�ڂ�����邩
				[�ȉ��̂��̂�reverse_transitionelem_num�̐��������݂���]
					[fldata]	�t�J�ڐ�id

				[fldata]	connectionelem_num �֘A�悪����邩
				[�ȉ��̂��̂�connectionelem_num�̐��������݂���]
					[fldata]	�֘A��id
					[fldata]	�X�R�A
			*/

		private:
			//map�̊��
			//����Ȃ�ă_�b�N�v���O���~���O
			template<typename T, typename U> struct base_map{
				int length;
				typedef T element_t;
				element_t *data;
				enum{ nil = -1 };

			public:
				//realloc
				//�̈���w�肵���T�C�Y�ōĊm��
				void realloc(int n){
					if(n == 0){
						length = 0;
						delete[] data;
						data = NULL;
						return;
					}

					if(n == length) return;

					element_t *nptr = new element_t[n];
					std::memcpy(
						reinterpret_cast<void*>(nptr),
						reinterpret_cast<const void*>(data),
						(std::min)(length, n) * sizeof(T)
					);
					delete[] data;
					length = n;
					data = nptr;
				}

				//�����N�ɒǉ�
				//���ɂ���΃X�R�A���C���N�������g
				void insert(int id){
					for(int i = 0; i < length; ++i){
						if(data[i].get_id() == id){
							data[i].score_increment();
							return;
						}
					}

					realloc(length + 1);
					data[length - 1].init();
					data[length - 1].get_id() = id;
				}

				//�Y������id�̗v�f��T��
				element_t *find(int id){
					for(int i = 0; i < length; ++i){
						if(data[i].get_id() == id) return &data[i];
					}

					return NULL;
				}

				//�w�肵���v�f���폜����
				void erase(element_t *ptr){
					for(const element_t *const end = &data[length - 1]; ptr != end; ++ptr){
						std::memcpy(reinterpret_cast<void*>(ptr), reinterpret_cast<const void*>(ptr + 1), sizeof(element_t));
					}

					realloc(length - 1);
				}

				//�G���R�[�h
				void encode(compressed_data_t &cmp) const{
					delete[] cmp.data;
					cmp.data = element_t::encode(data, length, cmp.data_length);
				}

				//iterator���ǂ�
				class compressed_iterator{
					const compressed_data_t *cmp;
					int pos;

				public:
					bool operator ==(const compressed_iterator &it) const{
						return pos == it.pos;
					}

					bool operator !=(const compressed_iterator &it) const{
						return pos != it.pos;
					}

					bool operator <(const compressed_iterator &it) const{
						return pos < it.pos;
					}

					bool operator <=(const compressed_iterator &it) const{
						return pos <= it.pos;
					}

					bool operator >(const compressed_iterator &it) const{
						return pos > it.pos;
					}

					bool operator >=(const compressed_iterator &it) const{
						return pos >= it.pos;
					}

					compressed_iterator &operator =(const compressed_iterator &it){
						cmp = it.cmp;
						pos = it.pos;
						return *this;
					}

					const element_t operator *() const{
						return element_t::easy_decode(&cmp->data[pos]);
					}

					const element_t *operator ->() const{
						return &**this;
					}

					compressed_iterator &operator ++(){
						for(int i = 0; i < element_t::fl_length; ++i)
							pos += static_cast<int>(cmp->data[pos]) + 1;
						return *this;
					}

					//begin/end/data_length
					compressed_iterator begin() const{
						return compressed_iterator(*cmp);
					}

					compressed_iterator end() const{
						return compressed_iterator(*cmp, cmp->data_length);
					}

					compressed_iterator(const compressed_data_t &cmp_) :
						cmp(&cmp_),
						pos(0)
					{}

					compressed_iterator(const compressed_iterator &it) :
						cmp(&it.cmp),
						pos(it.pos)
					{}

					int data_length() const{
						return cmp->data_length;
					}

				private:
					compressed_iterator(const compressed_data_t &cmp_, int pos_) :
						cmp(&cmp_),
						pos(pos_)
					{}
				};

				void rvalue_destruction(){
					length = 0;
					data = NULL;
				}

				base_map(const compressed_data_t &cmp) :
					length(element_t::count(cmp)),
					data(length ? new element_t[length] : NULL)
				{
					if(length)
						element_t::decode(data, cmp, length);
				}

			protected:
				typedef tty::move_t<base_map> move_t;
			public:

				base_map(move_t &m) :
					length(m.get().length),
					data(m.get().data)
				{}

				base_map(const base_map &a) :
					length(a.length),
					data(new element_t[length])
				{
					std::memcpy(
						reinterpret_cast<void*>(data),
						reinterpret_cast<const void*>(a.data),
						sizeof(int) * length
					);
				}

				base_map() :
					length(0),
					data(NULL)
				{}

				~base_map(){
					delete[] data;
				}
			};
		public:



#define m_test(z, i, s) \
	BOOST_PP_SEQ_ELEM(0, BOOST_PP_SEQ_ELEM(i, s)) BOOST_PP_SEQ_ELEM(1, BOOST_PP_SEQ_ELEM(i, s));

#define m_count(a) \
	inline static int count(compressed_data_t cmp){ \
		int i , e; \
		tty::fldata::data_t ptr = cmp.data; \
		for(i = 0, e = cmp.data_length; static_cast<int>(ptr - cmp.data) < e; ++i){ \
			BOOST_PP_REPEAT(a, m_count_i, nil) \
		} \
		return i; \
	}

#define m_count_i(z, y, x) \
	ptr = fldata_next(ptr);

#define m_decode(t, s) \
	inline static void decode(t *data, const compressed_data_t &cmp, int elem_num){ \
		tty::fldata::data_t ptr = cmp.data; \
		int tmp; \
		for(int i = 0; i < elem_num; ++i){ BOOST_PP_REPEAT(BOOST_PP_SEQ_SIZE(s), m_decode_i, s) } \
	}

#define m_decode_i(z, c, s) \
	data[i].BOOST_PP_SEQ_ELEM(1, BOOST_PP_SEQ_ELEM(c, s)) \
			= tty::fldata::decode<BOOST_PP_SEQ_ELEM(0, BOOST_PP_SEQ_ELEM(c, s))>(ptr, tmp); \
	ptr = &ptr[tmp];

#define m_encode(t, s) \
	inline static int encode_count(t *data, int elem_num){ \
		int r = 0; \
		for(int i = 0; i < elem_num; ++i){ BOOST_PP_REPEAT(BOOST_PP_SEQ_SIZE(s), m_encode_i, s) } \
		return r; \
	} \
	inline static tty::fldata::data_t encode(t *data, int elem_num, int &length){ \
		length = encode_count(data, elem_num); \
		tty::fldata::data_t rdata = new tty::fldata::segment_t[length], ndata; \
		ndata = rdata; \
		for(int i = 0; i < elem_num; ++i){ BOOST_PP_REPEAT(BOOST_PP_SEQ_SIZE(s), m_encode_ii, s) } \
		return rdata; \
	}

#define m_encode_i(z, c, s) \
	r += tty::fldata::sl(data[i].BOOST_PP_SEQ_ELEM(1, BOOST_PP_SEQ_ELEM(c, s)));

#define m_encode_ii(z, c, s) \
	ndata = &ndata[tty::fldata::encode_na(ndata, data[i].BOOST_PP_SEQ_ELEM(1, BOOST_PP_SEQ_ELEM(c, s)))];

#define m_easy_decode(t, s) \
	inline static t easy_decode(tty::fldata::data_t data){ \
		t r; \
		int num; \
		BOOST_PP_REPEAT(BOOST_PP_SEQ_SIZE(s), m_easy_decode_i, s) \
		return r; \
	}

#define m_easy_decode_i(z, c, s) \
	r.BOOST_PP_SEQ_ELEM(1, BOOST_PP_SEQ_ELEM(c, s)) \
		= tty::fldata::decode<BOOST_PP_SEQ_ELEM(0, BOOST_PP_SEQ_ELEM(c, s))>(data, num); \
	data = &data[num];

#define m_operator(t, s) \
	bool operator ==(const t &rhs) const{ return const_get_id() == rhs.const_get_id(); } \
	bool operator !=(const t &rhs) const{ return const_get_id() != rhs.const_get_id(); } \
	bool operator <(const t &rhs) const{ return const_get_id() < rhs.const_get_id(); } \
	bool operator <=(const t &rhs) const{ return const_get_id() <= rhs.const_get_id(); } \
	bool operator >(const t &rhs) const{ return const_get_id() > rhs.const_get_id(); } \
	bool operator >=(const t &rhs) const{ return const_get_id() >= rhs.const_get_id(); }

#define m_define(t, s) \
	BOOST_PP_REPEAT(BOOST_PP_SEQ_SIZE(s), m_test, s) \
	m_count(BOOST_PP_SEQ_SIZE(s)); \
	m_decode(t, s); \
	m_encode(t, s); \
	m_easy_decode(t, s) \
	m_operator(t, s) \
	enum{ fl_length = BOOST_PP_SEQ_SIZE(s) };

			//map

			//�J��
			struct transitionmap_element_t{
				m_define(
					transitionmap_element_t,
					((int)(dst_id))((int)(score))
				);

				inline void init(){
					score = 0;
				}

				inline int &get_id(){
					return dst_id;
				}

				inline int const_get_id() const{
					return dst_id;
				}

				inline void score_increment(){
					++score;
				}

				inline void score_decrement(){
					--score;
				}
			};
			struct transitionmap_t : base_map<transitionmap_element_t, transitionmap_t>{
				transitionmap_t() : base_map(){}
				transitionmap_t(const compressed_data_t &cmp) : base_map(cmp){}
				transitionmap_t(move_t &m) : base_map(m){}
			};

			//�t�J��
			struct reverse_transitionmap_element_t{
				m_define(
					reverse_transitionmap_element_t,
					((int)(src_id))
				);

				inline void init(){}

				inline int &get_id(){
					return src_id;
				}

				inline int const_get_id() const{
					return src_id;
				}

				inline void score_increment(){}
				inline void score_decrement(){}
			};
			struct reverse_transitionmap_t : base_map<reverse_transitionmap_element_t, reverse_transitionmap_t>{
				reverse_transitionmap_t() : base_map(){}
				reverse_transitionmap_t(const compressed_data_t &cmp) : base_map(cmp){}
				reverse_transitionmap_t(move_t &m) : base_map(m){}
			};

			//�֘A
			struct connectionmap_element_t{
				m_define(
					connectionmap_element_t,
					((int)(dst_id))((int)(score))
				);

				inline void init(){
					score = 0;
				}

				inline int &get_id(){
					return dst_id;
				}

				inline int const_get_id() const{
					return dst_id;
				}

				inline void score_increment(){
					++score;
				}

				inline void score_decrement(){
					--score;
				}
			};
			struct connectionmap_t : base_map<connectionmap_element_t, connectionmap_t>{
				connectionmap_t() : base_map(){}
				connectionmap_t(const compressed_data_t &cmp) : base_map(cmp){}
				connectionmap_t(move_t &m) : base_map(m){}
			};

			//���p�I�p�@
			struct idiomconnectionmap_element_t{
				m_define(
					idiomconnectionmap_element_t,
					((int)(idiom_id))/*((int)(score))*/
				);

				inline void init(){
					/*score = 0;*/
				}

				inline int &get_id(){
					return idiom_id;
				}

				inline int const_get_id() const{
					return idiom_id;
				}

				inline void score_increment(){
					/*++score;*/
				}

				inline void score_decrement(){
					/*--score;*/
				}
			};
			struct idiomconnectionmap_t : base_map<idiomconnectionmap_element_t, idiomconnectionmap_t>{
				idiomconnectionmap_t() : base_map(){}
				idiomconnectionmap_t(const compressed_data_t &cmp) : base_map(cmp){}
				idiomconnectionmap_t(move_t &m) : base_map(m){}
			};

#undef m_test
#undef m_count
#undef m_count_i
#undef m_decode
#undef m_decode_i
#undef m_encode
#undef m_encode_i
#undef m_encode_ii
#undef m_easy_decode
#undef m_easy_decode_i
#undef m_operator
#undef m_define

			int id; //id
			int value; //�o����

			compressed_data_t
				compressed_transitionmap,		//�J��
				compressed_reverse_transitionmap,//�t�J��
				compressed_connectionmap,		//�֘A
				compressed_idiomconnectionmap;	//���p�I�p�@�֘A

			//read
			void read(std::fstream &f){
				using tty::fldata::read;

				//id, value
				//std::size_t tellg_result = f.tellg();
				tty::fldata::read(f, id);
				tty::fldata::read(f, value);

				read(f, compressed_transitionmap.data_length);
				if(compressed_transitionmap.data_length){
					compressed_transitionmap.data = new tty::fldata::segment_t[compressed_transitionmap.data_length];
					f.read(
						reinterpret_cast<char*>(compressed_transitionmap.data),
						static_cast<std::streamsize>(compressed_transitionmap.data_length)
					);
				}else{
					compressed_transitionmap.data = NULL;
				}

				read(f, compressed_reverse_transitionmap.data_length);
				if(compressed_reverse_transitionmap.data_length){
					compressed_reverse_transitionmap.data = new tty::fldata::segment_t[compressed_reverse_transitionmap.data_length];
					f.read(
						reinterpret_cast<char*>(compressed_reverse_transitionmap.data),
						static_cast<std::streamsize>(compressed_reverse_transitionmap.data_length)
					);
				}else{
					compressed_reverse_transitionmap.data = NULL;
				}

				read(f, compressed_connectionmap.data_length);
				if(compressed_connectionmap.data_length){
					compressed_connectionmap.data = new tty::fldata::segment_t[compressed_connectionmap.data_length];
					f.read(
						reinterpret_cast<char*>(compressed_connectionmap.data),
						static_cast<std::streamsize>(compressed_connectionmap.data_length)
					);
				}else{
					compressed_connectionmap.data = NULL;
				}

				read(f, compressed_idiomconnectionmap.data_length);
				if(compressed_idiomconnectionmap.data_length){
					compressed_idiomconnectionmap.data = new tty::fldata::segment_t[compressed_idiomconnectionmap.data_length];
					f.read(
						reinterpret_cast<char*>(compressed_idiomconnectionmap.data),
						static_cast<std::streamsize>(compressed_idiomconnectionmap.data_length)
					);
				}else{
					compressed_idiomconnectionmap.data = NULL;
				}
			}

			//write
			void write(std::fstream &f) const{
				using tty::fldata::write;

				//id, value
				write(f, id);
				write(f, value);

				write(f, compressed_transitionmap.data_length);
				if(compressed_transitionmap.data_length)
					f.write(
						reinterpret_cast<const char*>(compressed_transitionmap.data),
						static_cast<std::streamsize>(compressed_transitionmap.data_length)
					);

				write(f, compressed_reverse_transitionmap.data_length);
				if(compressed_reverse_transitionmap.data_length)
					f.write(
						reinterpret_cast<const char*>(compressed_reverse_transitionmap.data),
						static_cast<std::streamsize>(compressed_reverse_transitionmap.data_length)
					);

				write(f, compressed_connectionmap.data_length);
				if(compressed_connectionmap.data_length)
					f.write(
						reinterpret_cast<const char*>(compressed_connectionmap.data),
						static_cast<std::streamsize>(compressed_connectionmap.data_length)
					);

				write(f, compressed_idiomconnectionmap.data_length);
				if(compressed_idiomconnectionmap.data_length)
					f.write(
						reinterpret_cast<const char*>(compressed_idiomconnectionmap.data),
						static_cast<std::streamsize>(compressed_idiomconnectionmap.data_length)
					);
			}

			void destroy() const{
				//
				delete[] compressed_transitionmap.data;
				delete[] compressed_reverse_transitionmap.data;
				delete[] compressed_connectionmap.data;
				delete[] compressed_idiomconnectionmap.data;
			}

		private:
			//����fldata��Ԃ�
			inline static tty::fldata::data_t fldata_next(tty::fldata::data_t a){
				tty::fldata::segment_t t = a[0];
				return a + t + 1;
			}

			//fldata�̉򂪊���邩���J�E���g
			inline static int fldata_count(tty::fldata::data_t a, int data_length){
				tty::fldata::data_t p = a;
				int i;
				for(i = 0; static_cast<int>(p - a) != data_length; ++i, p = fldata_next(p));
				return i;
			}
		};

		//���^
	public:
		struct key_t{
			const wchar_t **str; //NULL�����͓���Ȃ�
			int length;

			static boost::pool<>* &ptr_pool(){
				static boost::pool<> *pool;
				return pool;
			}

			static const wchar_t **ptr_alloc(){
				return static_cast<const wchar_t**>(ptr_pool()->malloc());
			}

			static void free_ptr(const wchar_t **ptr){
				ptr_pool()->free(ptr);
			}

			static key_t create(const wchar_t *s, int v){
				key_t r;
				wchar_t *ptr = new wchar_t[v];
				tty::memcpy(ptr, s, v);
				r.str = ptr_alloc();
				*r.str = ptr;
				r.length = v;
				return r;
			}

			static key_t create(const wchar_t *s){
				return create(s, tty::ta_length(s));
			}

			static key_t create(const std::wstring str){
				return create(str.c_str(), static_cast<int>(str.size()));
			}

			void destroy() const{
				delete[] *str;
				ptr_pool()->free(str);
			}

			static key_t create_virtual(const wchar_t *s, int l){
				key_t r;
				r.str = ptr_alloc();
				*r.str = s;
				r.length = l;
				return r;
			}

			static void substantiation(const key_t &a){
				wchar_t *buff = new wchar_t[a.length];
				tty::memcpy(buff, *a.str, a.length);
				*a.str = buff;
			}

			static void destroy_virtual(const key_t &a){
				ptr_pool()->free(a.str);
			}
		};

		//�����f�[�^��map�̌^
	private:
		static_assert(boost::is_pod<dic_t::data_t>::value);
		static_assert(boost::is_pod<dic_t::key_t>::value);
		class map_t : public std::map<key_t, data_t>{
		public:
			//�A�b�v�L���X�g
			//�X�[�p�[�N���X�Ƃ��Ă̗��p�͎g�p�𖾋L���Ȃ��Ƃ����Ȃ�
			typedef std::map<key_t, data_t> base_class;
			inline base_class *up_cast(){
				return this;
			}

			//erase
			void erase(iterator position){
				position->first.destroy();
				position->second.destroy();

				up_cast()->erase(position);
			}

			iterator erase(const key_type& x){
				base_class *ptr = up_cast();
				iterator it = find(x);

				it->first.destroy();
				it->second.destroy();

				return up_cast()->erase(it);
			}

			void erase(iterator first, iterator last){
				for(; first != last; ++first){
					first->first.destroy();
					first->second.destroy();
				}

				up_cast()->erase(first, last);
			}

			void clear(){
				for(
					map_t::const_iterator i = begin(), e = end();
					i != e;
					++i
				){
					i->first.destroy();
					i->second.destroy();
				}

				up_cast()->clear();
			}

			~map_t(){
				for(
					map_t::const_iterator i = begin(), e = end();
					i != e;
					++i
				){
					i->first.destroy();
					i->second.destroy();
				}
			}
		};

	public:
		struct idmap_value_t{
			const key_t *ptr_key;
			data_t *ptr_data;
		};
		typedef tty::rope_array<idmap_value_t, 0x800 / sizeof(idmap_value_t) - 1> idmap_t;

		//���p�I�p�@
		typedef tty::lcsubsequence<int>::resultseq_t idiom_t;
		typedef tty::rope_array<const idiom_t*, 0x200 / sizeof(idmap_value_t) - 1> idiomidmap_t;
		class idiommap_t : public std::set<idiom_t>{
			friend data_t;
		public:
			map_t &map;
			idmap_t &idmap;
			idiomidmap_t &idiomidmap;

			typedef std::set<idiom_t> base_class;
			inline base_class *up_cast(){
				return this;
			}

			//erase
			void erase(iterator it){
				elem_destroy(*it);
				up_cast()->erase(it);
			}

			//k�ɂ͎����̃R���e�i���̗v�f��������Ă͂Ȃ�Ȃ�
			//id�}�b�v����폜����������
			size_type erase(const key_type &k){
				elem_destroy(k);
				return up_cast()->erase(k);
			}

			void erase(int id){
				erase(*idiomidmap[id]);
				idiomidmap[id] = NULL;
			}

			inline idiommap_t(
				map_t &map_,
				idmap_t &idmap_,
				idiomidmap_t &idiomidmap_
			) : map(map_), idmap(idmap_), idiomidmap(idiomidmap_){}

			~idiommap_t(){
				for(
					const_iterator it = begin(), e = end();
					it != e;
					++it
				){
					delete[] it->data;
					delete[] it->chain;
				}
			}

		private:
			void elem_destroy(const idiom_t &elem) const{
				for(int i = 0; i < elem.length; ++i){
					const idmap_value_t &iv(idmap[elem.data[i]]);
					data_t::idiomconnectionmap_t tmap(iv.ptr_data->compressed_idiomconnectionmap);
					tmap.erase(tmap.find(elem.data[i]));
					tmap.encode(iv.ptr_data->compressed_idiomconnectionmap);
				}

				delete[] elem.data;
				delete[] elem.chain;
			}
		};

	public:
		typedef std::pair<map_t::iterator, bool> insert_result_t;
		typedef map_t::iterator iterator;
		typedef map_t::const_iterator const_iterator;
		typedef idiommap_t::iterator idiommap_iterator;
		typedef idiommap_t::const_iterator idiommap_const_iterator;

		//halfway disabled id
	private:
		typedef std::deque<int> hdid_t;

		//------ �v���C�x�[�g�ȃ����o
	private:
		//�L�[�ւ̃|�C���^�����
		boost::pool<> key_strv_pool;

		//�}�b�v
		map_t map;
		idmap_t idmap;

		//�C�f�B�I���}�b�v
		idiomidmap_t idiomidmap;
		idiommap_t idiommap;

		//halfway disabled id
		hdid_t hdid, idiom_hdid;

		//------ method
		//       public private����

		//insert
		//�f�[�^�ݒ��x������}��.
	public:
		insert_result_t insert(const wchar_t *str, int l){
			key_t key = key_t::create_virtual(str, l);
			insert_result_t r = map.insert(
				std::pair<key_t, data_t>(key, data_t())
			);

			//�������m�ہA�f�[�^�ݒ��x��
			if(r.second){
				//���̕���������̉�����
				key_t::substantiation(r.first->first);

				//�f�[�^�ݒ�
				if(hdid.size()){
					r.first->second.id = hdid.back();
					hdid.pop_back();
				}else{
					r.first->second.id = idmap.size();
				}

				//idmap�ɂ�����
				idmap_value_t idmap_value;
				idmap_value.ptr_key = &r.first->first;
				idmap_value.ptr_data = &r.first->second;
				idmap.push_back(idmap_value);
			}else{
				++r.first->second.value;
				key_t::destroy_virtual(key);
			}

			return r;
		}

		//insert_idiom
		//�}�����id��Ԃ�
		//���s�����ꍇ��id�͖���
	public:
		struct insert_idiom_result_t{
			int id;
			bool result_flag;
		};

		insert_idiom_result_t insert_idiom(idiom_t idiom){
			std::pair<idiommap_t::iterator, bool> rit = idiommap.insert(idiom);
			if(!rit.second){
				insert_idiom_result_t r;
				r.result_flag = false;
				return r;
			}

			insert_idiom_result_t result;
			result.result_flag = rit.second;

			//id��^����
			int r;
			if(idiom_hdid.size()){
				r = idiom_hdid.back();
				idiom_hdid.pop_back();
			}else{
				r = static_cast<int>(idiomidmap.size());
			}
			idiomidmap.aeg(r) = &*rit.first;

			result.id = r;
			return result;
		}

		//find_idiom
		//idiom�������Ă���
	public:
		const idiom_t &find_idiom(int id) const{
			return *idiomidmap[id];
		}

		//size/begin/end/find/erase
	public:
		int size() const{
			return static_cast<int>(map.size());
		}

		int idiommap_size() const{
			return static_cast<int>(idiommap.size());
		}

		iterator begin(){
			return map.begin();
		}

		iterator end(){
			return map.end();
		}

		const_iterator begin() const{
			return map.begin();
		}

		const_iterator end() const{
			return map.end();
		}

		iterator find(const map_t::key_type &key){
			return map.find(key);
		}

		idmap_value_t find(int idx){
			return idmap[idx];
		}

		void erase(iterator it){
			cutlink(it->second);
			hdid.push_back(it->second.id);
			map.erase(it);
		}

		void erase(int id){
			erase(map.find(*idmap[id].ptr_key));
		}

		//�P��̗v�f���e��map����ؒf
	private:
		void cutlink(data_t &data){
			//transitionmap
			const data_t::transitionmap_t transitionmap(data.compressed_transitionmap);
			for(int i = 0; i < transitionmap.length; ++i){
				const idmap_value_t &iv(find(transitionmap.data[i].dst_id));
				data_t::reverse_transitionmap_t tmap(iv.ptr_data->compressed_reverse_transitionmap);
				tmap.erase(tmap.find(data.id));
				tmap.encode(iv.ptr_data->compressed_reverse_transitionmap);
			}

			//reverse_transitionmap
			const data_t::reverse_transitionmap_t reverse_transitionmap(data.compressed_reverse_transitionmap);
			for(int i = 0; i < reverse_transitionmap.length; ++i){
				const idmap_value_t &iv(find(reverse_transitionmap.data[i].src_id));
				data_t::transitionmap_t tmap(iv.ptr_data->compressed_transitionmap);
				tmap.erase(tmap.find(data.id));
				tmap.encode(iv.ptr_data->compressed_transitionmap);
			}

			//connectionmap
			const data_t::connectionmap_t connectionmap(data.compressed_connectionmap);
			for(int i = 0; i < connectionmap.length; ++i){
				const idmap_value_t &iv(find(connectionmap.data[i].dst_id));
				data_t::connectionmap_t tmap(iv.ptr_data->compressed_connectionmap);
				tmap.erase(tmap.find(data.id));
				tmap.encode(iv.ptr_data->compressed_connectionmap);
			}

			//idiomconnectionmap
			//idiommap
			const data_t::idiomconnectionmap_t idiomconnectionmap(data.compressed_idiomconnectionmap);
			for(int i = 0; i < idiomconnectionmap.length; ++i){
				idiommap.erase(idiomconnectionmap.data[i].idiom_id);
			}
		}

		//read_hdid
	private:
		bool read_hdid(){
			std::fstream f(datafilepath.hdid().char_str(), std::ios::in | std::ios::binary);
			if(f.fail()) return false;

			//�t�@�C���T�C�Y
			f.seekg(0, std::fstream::end);
			std::streamsize size = f.tellg(); f.seekg(0);

			int value;
			for(
				f.read(reinterpret_cast<char*>(&value), sizeof(int));
				!f.fail();
				f.read(reinterpret_cast<char*>(&value), sizeof(int))
			){
				hdid.push_back(value);
			}

			return true;
		}

		//write_hdid
	private:
		void write_hdid() const{
			std::fstream f(datafilepath.hdid().char_str(), std::ios::out | std::ios::binary);

			for(
				hdid_t::const_iterator it = hdid.begin(), end = hdid.end();
				it != end;
				++it
			){
				f.write(reinterpret_cast<const char*>(&*it), sizeof(int));
			}
		}

		//read_idiom_hdid
	private:
		bool read_idiom_hdid(){
			std::fstream f(datafilepath.idiom_hdid().char_str(), std::ios::in | std::ios::binary);
			if(f.fail()) return false;

			f.seekg(0, std::fstream::end); std::streamsize size = f.tellg(); f.seekg(0);

			int value;
			for(
				f.read(reinterpret_cast<char*>(&value), sizeof(int));
				!f.fail();
				f.read(reinterpret_cast<char*>(&value), sizeof(int))
			){
				idiom_hdid.push_back(value);
			}

			return true;
		}

		//write_idiom_hdid
	private:
		void write_idiom_hdid() const{
			std::fstream f(datafilepath.idiom_hdid().char_str(), std::ios::out | std::ios::binary);

			for(
				hdid_t::const_iterator it = idiom_hdid.begin(), end = idiom_hdid.end();
				it != end;
				++it
			){
				f.write(reinterpret_cast<const char*>(&*it), sizeof(int));
			}
		}

		//read_idiomdic
	private:
		bool read_idiomdic(){
			std::fstream f(
				datafilepath.idiomdic().char_str(),
				std::ios::in | std::ios::binary
			);
			if(f.fail()) return false;

			//�t�@�C���T�C�Y�𓾂�
			f.seekg(0, std::fstream::end);
			std::streamsize size = f.tellg(); f.seekg(0);

			std::vector<unsigned char> chain_buff;
			idiom_t idiom;
			int i;
			for(tty::fldata::read(f, i); !f.fail(); tty::fldata::read(f, i)){
				//length
				tty::fldata::read(f, idiom.length);
				idiom.data = new int[idiom.length];
				idiom.chain = new bool[idiom.length];

				//�P���id
				for(int j = 0; j < idiom.length; ++j){
					tty::fldata::read(f, idiom.data[j]);
				}

				//�`�F�C��
				chain_buff.resize(idiom.length / 8 + ((idiom.length % 8) ? 1 : 0));
				f.read(reinterpret_cast<char*>(&chain_buff[0]), static_cast<std::streamsize>(chain_buff.size()));
				for(int j = 0; j < idiom.length; ++j){
					const unsigned char &buff(chain_buff[j / 8]);
					idiom.chain[j] = (buff & (static_cast<unsigned char>(1) << (j % 8))) ? true : false;
				}

				std::pair<idiommap_t::iterator, bool> r = idiommap.insert(idiom);
				idiomidmap.aeg(i) = &*r.first;
			}

			return true;
		}

		//write_idiomdic
	private:
		void write_idiomdic() const{
			std::fstream f(datafilepath.idiomdic().char_str(), std::ios::out | std::ios::binary);

			std::vector<unsigned char> chain_buff;
			chain_buff.reserve(0xFF);

			for(int i = 0, e = static_cast<int>(idiommap.size()); i < e; ++i){
				//id
				tty::fldata::write(f, i);
				//length
				tty::fldata::write(f, idiomidmap[i]->length);

				//�P���id
				for(int j = 0; j < idiomidmap[i]->length; ++j){
					tty::fldata::write(f, idiomidmap[i]->data[j]);
				}

				//�`�F�C��
				chain_buff.resize(idiomidmap[i]->length / 8 + ((idiomidmap[i]->length % 8) ? 1 : 0));
				for(int j = 0, je = static_cast<int>(idiomidmap[i]->length); j < je; ++j){
					unsigned char &buff(chain_buff[j / 8]);
					if(idiomidmap[i]->chain[j]){
						buff |= static_cast<unsigned char>(1) << (j % 8);
					}else{
						buff &= ~(static_cast<unsigned char>(1) << (j % 8));
					}
				}
				f.write(
					reinterpret_cast<const char*>(&chain_buff[0]),
					static_cast<std::streamsize>(chain_buff.size())
				);
			}
		}

		//raed_dic
	private:
		bool read_dic(){
			std::fstream f(
				datafilepath.dic().char_str(),
				std::ios::in | std::ios::binary
			);
			if(f.fail()) return false;

			//�t�@�C���T�C�Y�𓾂�
			f.seekg(0, std::fstream::end);
			std::streamsize size = f.tellg(); f.seekg(0);

			data_t data;
			insert_result_t insert_result;
			wchar_t ch;
			std::vector<wchar_t> str; str.reserve(0x200);

			for(
				f.read(reinterpret_cast<char*>(&ch), sizeof(wchar_t));
				!f.fail();
				f.read(reinterpret_cast<char*>(&ch), sizeof(wchar_t))
			){
				str.push_back(ch);
				if(!ch){
					data.read(f);

					insert_result = map.insert(
						map_t::value_type(
							key_t::create(
								&str[0],
								static_cast<int>(str.size() - 1)
							),
							data
						)
					);

					idmap_value_t &idmap_value(idmap.aeg(data.id));
					idmap_value.ptr_key = &insert_result.first->first;
					idmap_value.ptr_data = &insert_result.first->second;

					str.clear();
				}
			}

			return true;
		}

		//write_dic
	private:
		void write_dic() const{
			std::fstream f(
				datafilepath.dic().char_str(),
				std::ios::out | std::ios::binary
			);

			std::vector<wchar_t> v;
			v.reserve(0xFF);

			for(
				map_t::const_iterator it = map.begin(), end = map.end();
				it != end;
				++it
			){
				v.resize(it->first.length + 1);
				tty::memcpy(&v[0], *it->first.str, it->first.length);
				v[it->first.length] = 0;

				//������������o��
				f.write(
					reinterpret_cast<const char*>(&v[0]),
					static_cast<std::streamsize>(v.size() * sizeof(wchar_t))
				);

				//�f�[�^�������o��
				it->second.write(f);
			}

			return;
		}

		//read
	public:
		bool read(){
			if(!read_idiom_hdid())
				return false;
			if(!read_idiomdic())
				return false;
			if(!read_hdid())
				return false;
			if(!read_dic())
				return false;
			return true;
		}

		//write
	public:
		void write() const{
			write_idiom_hdid();
			write_idiomdic();
			write_hdid();
			write_dic();
		}

		//�S�Ă̒P��������o��
	public:
		void allput(){
			std::fstream f("words.bin", std::ios::out | std::ios::binary);
			std::vector<wchar_t> vec;

			for(
				map_t::const_iterator it = map.begin(), end = map.end();
				it != end;
				++it
			){
				vec.resize(it->first.length + 1);
				vec[vec.size() - 1] = 0;
				std::memcpy(reinterpret_cast<void*>(&vec[0]), reinterpret_cast<const void*>(*it->first.str), it->first.length * sizeof(wchar_t));
				f.write(reinterpret_cast<const char*>(&vec[0]), static_cast<std::streamsize>(vec.size() * sizeof(wchar_t)));
			}
		}

		//�R���X�g���N�^
	public:
		dic_t() : key_strv_pool(sizeof(wchar_t)), idiommap(map, idmap, idiomidmap){
			key_t::ptr_pool() = &key_strv_pool;
		}

		//�f�X�g���N�^
	public:
		~dic_t(){}
	};

	//dic_t::key_t�̃I�y���[�^
	bool operator <(const dic_t::key_t &lhs, const dic_t::key_t &rhs){
		if(lhs.length == rhs.length){
			for(int i = 0; i < lhs.length; ++i){
				if((*lhs.str)[i] == (*rhs.str)[i]) continue;
				return (*lhs.str)[i] < (*rhs.str)[i];
			}

			return false;
		}else{
			return lhs.length < rhs.length;
		}
	}

	bool operator <=(const dic_t::key_t &lhs, const dic_t::key_t &rhs){
		if(lhs.length == rhs.length){
			for(int i = 0; i < lhs.length; ++i){
				if((*lhs.str)[i] == (*rhs.str)[i]) continue;
				return (*lhs.str)[i] < (*rhs.str)[i];
			}

			return true;
		}else{
			return lhs.length < rhs.length;
		}
	}

	bool operator >(const dic_t::key_t &lhs, const dic_t::key_t &rhs){
		if(lhs.length == rhs.length){
			for(int i = 0; i < lhs.length; ++i){
				if((*lhs.str)[i] == (*rhs.str)[i]) continue;
				return (*lhs.str)[i] > (*rhs.str)[i];
			}

			return false;
		}else{
			return lhs.length > rhs.length;
		}
	}

	bool operator >=(const dic_t::key_t &lhs, const dic_t::key_t &rhs){
		if(lhs.length == rhs.length){
			for(int i = 0; i < lhs.length; ++i){
				if((*lhs.str)[i] == (*rhs.str)[i]) continue;
				return (*lhs.str)[i] > (*rhs.str)[i];
			}

			return true;
		}else{
			return lhs.length > rhs.length;
		}
	}

	bool operator ==(const dic_t::key_t &lhs, const dic_t::key_t &rhs){
		if(lhs.length == rhs.length){
			for(int i = 0; i < lhs.length; ++i){
				if((*lhs.str)[i] == (*rhs.str)[i]) continue;
				return false;
			}

			return true;
		}else{
			return false;
		}
	}

	bool operator !=(const dic_t::key_t &lhs, const dic_t::key_t &rhs){
		if(lhs.length == rhs.length){
			for(int i = 0; i < lhs.length; ++i){
				if((*lhs.str)[i] == (*rhs.str)[i]) continue;
				return true;
			}

			return false;
		}else{
			return true;
		}
	}

	dic_t dic;
}
