/*
	STL _SECURE_SCL �� 0 �ɐݒ肷��
*/

#ifndef __TTY_SSS_ZERO__
#define __TTY_SSS_ZERO__

#ifdef _MSC_VER
#define _SECURE_SCL 0
#endif

#endif // __TTY_SSS_ZERO__
