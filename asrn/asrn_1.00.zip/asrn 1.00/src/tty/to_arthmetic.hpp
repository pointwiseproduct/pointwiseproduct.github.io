#ifndef __TTY_TO_ARTHMETIC__
#define __TTY_TO_ARTHMETIC__

#include <stdint.h>

namespace tty{
	template<typename T> struct to_arthmetic{
	private:
		template<int a> struct t2a;
		template<> struct t2a<1>{
			typedef char t1;
			typedef unsigned char t2;
		};
		template<> struct t2a<2>{
			typedef short t1;
			typedef unsigned short t2;
		};
		template<> struct t2a<3>{
			typedef int t1;
			typedef unsigned int t2;
		};
		template<> struct t2a<4>{
			typedef int t1;
			typedef unsigned int t2;
		};

		template<int n> struct cm{
			enum{ val = (0xFF << (8 * (n - 1))) | cm<n - 1>::val };
		};

		template<> struct cm<1>{
			enum{ val = 0xFF };
		};

		template<> struct cm<0>{
			enum{ val = 0 };
		};

		typedef t2a<sizeof(T)> ts;

	public:
		typedef typename ts::t1 signed_type;
		typedef typename ts::t2 unsigned_type;
		enum{ mask = cm<sizeof(T)>::val };
	};
}

#endif //__TTY_TO_ARTHMETIC__

