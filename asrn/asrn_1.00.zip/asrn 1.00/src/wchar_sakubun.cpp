#include <tty/sss_zero.hpp>
#include <string>
#include <iostream>
#include <fstream>
#include <ctime>
#include <cstdlib>
#include <cassert>
#include <conio.h>
#include <boost/type_traits.hpp>
#include <boost/static_assert.hpp>
#include <boost/timer.hpp>
#include <boost/random.hpp>
#include <tty/setlocale_japanese.hpp>
#include <tty/st.hpp>
#include <tty/quick_search.hpp>

#define static_assert BOOST_STATIC_ASSERT

#include "datafilepath.hpp"
#include "sentence_t.hpp"
#include "dic_t.hpp"
#include "log_t.hpp"

namespace strmorph{
	void in2log_and_analyze(const wchar_t *str){
		log.in(str);
		log.search_nmorph(0);
	}

	//wchar_t�ŕ\�����ꂽ�A�h���X��ϊ�����
	inline void waddr2caddr(std::string &str, const wchar_t *s){
		for(; *s != L'"'; ++s){
			if(*s >= L'a' && *s <= L'z'){
				str += static_cast<char>(*s - L'a' + 'a');
			}else if(*s >= L'A' && *s <= L'Z'){
				str += static_cast<char>(*s - L'A' + 'A');
			}else if(*s >= L'0' && *s <= L'9'){
				str += static_cast<char>(*s - L'0' + '0');
			}
#define asdf(a) else if(*s == L ## a){ str += a; }
			asdf('!')asdf('#')asdf('$')asdf('%')
			asdf('&')asdf('(')asdf(')')asdf('=')
			asdf('-')asdf('^')asdf('~')asdf('\\')
			asdf('|')asdf('@')asdf('`')asdf('[')
			asdf('{')asdf(']')asdf('}')asdf(';')
			asdf('+')asdf(':')asdf('*')asdf('<')
			asdf(',')asdf('.')asdf('>')asdf('/')
			asdf('?')asdf('_')asdf(' ')
#undef asdf
		}

#define asdf(s) \
	const char *list_a[] = { BOOST_PP_REPEAT(BOOST_PP_SEQ_SIZE(s), asdf_i, s) }; \
	const char *list_b[] = { BOOST_PP_REPEAT(BOOST_PP_SEQ_SIZE(s), asdf_ii, s) }; \
	const int list_strlength[] = { BOOST_PP_REPEAT(BOOST_PP_SEQ_SIZE(s), asdf_iii, s) }; \
	const int list_length = sizeof(list_strlength) / sizeof(*list_strlength);

#define asdf_i(z, i, s) BOOST_PP_SEQ_ELEM(0, BOOST_PP_SEQ_ELEM(i, s)),
#define asdf_ii(z, i, s) BOOST_PP_SEQ_ELEM(1, BOOST_PP_SEQ_ELEM(i, s)),
#define asdf_iii(z, i, s) tty::ta_length(BOOST_PP_SEQ_ELEM(0, BOOST_PP_SEQ_ELEM(i, s))),

		asdf(
			(("&nbsp;")(" "))
			(("&quot;")("\""))
			(("&amp;")("??"))
			(("&lt;")("<"))
			(("&gt;")(">"))
		);

		static tty::quick_search<char> search;

		for(int i = 0; i < list_length; ++i){
			search.preprocess(list_a[i], list_strlength[i]);
			int a = search(str.c_str(), static_cast<int>(str.size()));
			if(a == -1) continue;
			str.replace(a, list_strlength[i], list_b[i]);
		}

#undef asdf
#undef asdf_i
#undef asdf_ii
#undef asdf_iii
	}
}

#include "lwiki.hpp"

namespace strmorph{
	//�X���b�V���h�b�g�{�����w�K
	void slad(const char *seedaddr, int mstcounter_end){
		struct mark_t{
			const wchar_t *str;
			int length;
			mark_t(const wchar_t *str_) : str(str_), length(tty::ta_length(str_)){}
		};

		mark_t
			textstart_mark(L"<div class=\"intro\">"),
			textend_odiv(L"<div"),
			textend_cdiv(L"</div>"),
			linkstart_mark(L"<div class=\"prev-next\">"),
			linkstart_a_href(L"<a href=\""),
			linkend_mark(L"\">");

		std::fstream  file, xfile, addrfile("addrfile", std::ios::out);
		int filesize, buffsize = 0;
		//slashdot.jp/it/article.pl?sid=08/06/28/0021226
		//slashdot.jp/article.pl?sid=08/05/08/1059220
		std::string addr(seedaddr);
		wchar_t *buff = NULL;
		tty::quick_search<wchar_t> xsearch;
		std::wstring str;
		int strcnt = 0;

		boost::timer t, t_;

		//----------
		for(int mst_counter = 0; mst_counter < mstcounter_end; ++mst_counter){
			{
				std::string asdfstr = std::string("sladin.exe http:") + addr + std::string(" test.txt");
				std::cout << addr << std::endl;
				int r = std::system(asdfstr.c_str());
				if(r){
					std::cout << t_.elapsed() << std::endl << r << std::endl;
					#pragma warning(disable:4996)
					getch();
					#pragma warning(default:4996)
					return;
				}
			}

			t.restart();

			//open������Ƀt�@�C���T�C�Y�擾
			file.open("test.txt", std::ios::in | std::ios::binary);
			file.seekg(0, std::fstream::end);
			filesize = static_cast<int>(file.tellg()); file.seekg(0);

			if(filesize > buffsize){ //buff������Ȃ��ꍇ�͍Ċm��
				delete[] reinterpret_cast<char*>(buff);
				buff = reinterpret_cast<wchar_t*>(new char[filesize]);
				buffsize = filesize;
			}

			file.read(reinterpret_cast<char*>(buff), filesize);

			addrfile << mst_counter << " : " << addr << std::endl;

			file.close();

			int elmnum = filesize / (sizeof(wchar_t) / sizeof(char));

			//�{���𒊏o����
			int textstart, textend;
			xsearch.preprocess(textstart_mark.str, textstart_mark.length);
			textstart = xsearch(buff, elmnum) + textstart_mark.length;
			{
				int pos = textstart, end, t;
				for(;;){
					//</div>
					xsearch.preprocess(textend_cdiv.str, textend_cdiv.length);
					end = xsearch(&buff[pos], elmnum - pos) + pos;

					//</div>��pos�Ƃ̊Ԃ�<div�����邩
					xsearch.preprocess(textend_odiv.str, textend_odiv.length);
					if((t = xsearch(&buff[pos], end - pos)) == -1){
						textend = end;
						break;
					}else{
						pos = end + textend_cdiv.length;
					}
				}
			}

			int localcnt = 0;
			wchar_t tmp = 0;
			for(int i = textstart; i < textend; ++i){
				//�^�O�𖳎�����
				if(buff[i] == L'<'){
					struct{
						int operator()(const wchar_t *str, int i){
							int cnt = 0;
							for(++i; ; ++i){
								if(str[i] == L'<') ++cnt;
								if(str[i] == L'>')
									if(cnt > 0)
										--cnt;
									else
										break;
							}
							return i;
						}
					}avoid_tag;

					i = avoid_tag(buff, i);
					continue;
				}

				//�^�u�A���s��u������
				if(buff[i] == L'\t' || buff[i] == L'\n'){
					buff[i] = L' ';
				}

				//��_���o���Ƃ���ŉ�͂�����
				if(
					(buff[i] == L'�I') ||
					(buff[i] == L'!') ||
					(buff[i] == L'�H') ||
					(buff[i] == L'?') ||
					(buff[i] == L'�B') ||
					(buff[i] == L'�A') ||
					(buff[i] == L'�D') ||
					(buff[i] == L'�C') ||
					(buff[i] == L'.' && (tmp < L'0' || tmp > L'9') && tmp != L'/')  ||
					(buff[i] == L',') ||
					(buff[i] == L' ' && ((tmp < L'a' || tmp > L'z') || (tmp < L'A' || tmp > L'Z')) && (tmp != L'�B' && tmp != L'�D' && tmp != L'.')) ||
					(buff[i] == L'�@') ||
					(false)
				){
					std::wcout
						<< mst_counter << L":"
						<< strcnt << L":"
						<< localcnt /*<< L"\n>" << str << L"<"*/ << std::endl;

					if(str.size() >= 2)
						log.in(str.c_str());

					++strcnt; ++localcnt;
					str.clear();
					tmp = 0;
					continue;
				}

				str += buff[i];
				tmp = buff[i];
			}

			std::wcout
				<< std::endl
				<< t.elapsed() << L"�b�|����܂���" << std::endl
				<< "size : " << dic.idiommap_size() << std::endl
				<< std::endl;

			{
				std::fstream log("log", std::ios::out);
				log
					<< mst_counter << " / " << localcnt << " / " << strcnt << std::endl
					<< "http:" << addr << std::endl;
			}

			//�����N�𒊏o����
			int linkstart;
			{
				int tmp = textend + textend_cdiv.length, xstart;
				xsearch.preprocess(linkstart_mark.str, linkstart_mark.length);
				xstart = xsearch(&buff[tmp], elmnum - tmp) + tmp + linkstart_mark.length;

				xsearch.preprocess(linkstart_a_href.str, linkstart_a_href.length);
				linkstart = xsearch(&buff[xstart], elmnum - xstart) + xstart + linkstart_a_href.length;
			}
			addr.clear();
			waddr2caddr(addr, &buff[linkstart]);
		}

		delete[] reinterpret_cast<char*>(buff);
	}
}

void asrn(){
	if(!strmorph::dic.read()){
		std::cout << "�����̓ǂݍ��݂Ɏ��s���܂���..." << std::endl;
		return;
	}

	if(!strmorph::log.read()){
		std::cout << "���O�̓ǂݍ��݂Ɏ��s���܂���..." << std::endl;
		return;
	}

	boost::mt19937 gen(static_cast<unsigned int>(std::time(0)));
	std::wstring str;

	for(; ; ){
		std::wcout << L"user > ";
		std::wcin >> str;
		wchar_t tmpch = str.c_str()[0];
		if(tmpch == L'*' || tmpch == L'��') break;
		strmorph::log.in(str.c_str());
		strmorph::log.out(gen, str);
		std::wcout << L"asrn > " << str << std::endl;
		str.clear();
	}

	str.clear();
	std::wcout << L"s�Ŋw�K��Ԃ��Z�[�u���ďI�����܂�." << std::endl;
	if(_getch() == 's'){
		strmorph::dic.write();
		strmorph::log.write();
	}

	return;
}

int main(int argc, char *argv[]){
	asrn();

	return 0;
}
