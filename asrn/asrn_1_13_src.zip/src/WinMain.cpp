#include <tty/sss_zero.hpp>
#include <fstream>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <windows.h>
#include <commctrl.h>
#include <richedit.h>
#include <tty/setlocale_japanese.hpp>

#define CLASSNAME L"windows_wchar_saukubun version 1.12 y2008 m07 d28"
#define CONFIGFILE_NAME "config"
#define EDITBOX_ID 0xFF
#define SVCHECKBOX_ID 0x100

#include <string>
#include <ctime>
#include <cstdlib>
#include <cassert>
#include <conio.h>
#include <boost/type_traits.hpp>
#include <boost/static_assert.hpp>
#include <boost/timer.hpp>
#include <boost/random.hpp>
#include <tty/st.hpp>
#include <tty/quick_search.hpp>
#include "datafilepath.hpp"
#include "sentence_t.hpp"
#include "dic_t.hpp"
#include "log_t.hpp"

//�e��n���h��
HWND
	hlog,
	hsvcheck;

//�ݒ�
#pragma region
struct config_t{
	int err;
	bool svcheck;

	config_t() : err(0){
		std::fstream configfile;
		int i = 0;
		for(; ; ++i){
			configfile.open(CONFIGFILE_NAME, std::ios::in | std::ios::binary);
			if(configfile.fail()){
				if(i == 63) break;
				configfile.close();
				configfile.open(CONFIGFILE_NAME, std::ios::out | std::ios::binary);
				configfile.close();
				continue;
			}else{
				break;
			}
		}

		if(i >= 63){
			err = 1;
			return;
		}

		//read
		configfile.read(reinterpret_cast<char*>(&config.svcheck), sizeof(bool));
		if(configfile.fail()){
			config.svcheck = true;
		}
	}

	~config_t(){
		std::fstream configfile(CONFIGFILE_NAME, std::ios::out | std::ios::binary);
		configfile.write(reinterpret_cast<const char*>(&svcheck), sizeof(bool));
	}
}config;
#pragma endregion

//���O�t�@�C��
tty::wfstream logfile(L"log.txt", std::ios::out);

std::wstring asrn(const wchar_t *pstr){
	static boost::mt19937 gen(static_cast<unsigned int>(std::time(0)));
	static std::wstring str;

	strmorph::log.in(pstr);
	str.clear();
	strmorph::log.out(gen, str);

	return str;
}

#include "CreateID.hpp"
#include "WindowProc.hpp"

int WinMain(
	HINSTANCE	hInstance,
	HINSTANCE	hPrevInstence,
	LPSTR		lpCmdLine,
	int			nCmdShow
){
	//config
	#pragma region
	if(config.err){
		return 0;
	}
	#pragma endregion

	//asrn�̏�����
	#pragma region
	if(!strmorph::dic.read()){
		MessageBox(NULL, L"�����̓ǂݍ��݂Ɏ��s���܂���...", NULL, MB_OK);
		return 0;
	}

	if(!strmorph::log.read()){
		MessageBox(NULL, L"���O�̓ǂݍ��݂Ɏ��s���܂���...", NULL, MB_OK);
		return 0;
	}
	#pragma endregion

	//�E�B���h�E�̏�����
	#pragma region
	WNDCLASS wndclass;
	std::memset(&wndclass, 0, sizeof(WNDCLASS));
	wndclass.style = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc = WindowProc;
	wndclass.hInstance = hInstance;
	wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_3DFACE + 1);
	wndclass.lpszClassName = CLASSNAME;

	ATOM atom = RegisterClass(&wndclass);
	if(!atom){
		MessageBox(NULL, L"�E�B���h�E�N���X�̐����Ɏ��s���܂���", NULL, MB_OK);
		return 0;
	}

	HWND hwnd = CreateWindow(
		wndclass.lpszClassName,
		L"�l�H���] ������� ver 1.12",
		WS_OVERLAPPEDWINDOW ^ WS_MAXIMIZEBOX ^ WS_THICKFRAME,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		500, 362,
		NULL,
		NULL,
		hInstance,
		NULL
	);

	if(!hwnd){
		MessageBox(NULL, L"�E�B���h�E�N���X�̐����Ɏ��s���܂���", NULL, MB_OK);
		return 0;
	}
	#pragma endregion

	//�R���g���[���̏�����
	#pragma region
	LoadLibrary(L"RICHED20.DLL");

	//�G�f�B�b�g�{�b�N�X
	HWND heditbox = CreateWindowEx(
		WS_EX_CLIENTEDGE,
		RICHEDIT_CLASS,
		L"",
		WS_CHILD
			| WS_EX_CLIENTEDGE
			| WS_BORDER
			| WS_VISIBLE
			| WS_HSCROLL,
		0, 2,
		494, 48,
		hwnd,
		reinterpret_cast<HMENU>(EDITBOX_ID),
		hInstance,
		NULL
	);
	OrgPrc_EditBox = reinterpret_cast<FARPROC>(GetWindowLongPtr(heditbox, GWL_WNDPROC));
	if(!SetWindowLongPtr(
			heditbox,
			GWL_WNDPROC,
			reinterpret_cast<LONG_PTR>(EditBox_WindowProc)
	)){
		return 0;
	}

	//���O
	hlog = CreateWindowEx(
		WS_EX_CLIENTEDGE,
		RICHEDIT_CLASS,
		L"",
		WS_CHILD
			| WS_EX_CLIENTEDGE
			| WS_BORDER
			| WS_VISIBLE
			| ES_LEFT
			| ES_MULTILINE
			| ES_WANTRETURN
			| ES_READONLY
			| WS_VSCROLL,
		0, 50,
		494, 254,
		hwnd,
		reinterpret_cast<HMENU>(CreateID()),
		hInstance,
		NULL
	);

	//�`�F�b�N�{�b�N�X
	//"�I�����Ɋw�K��Ԃ�ۑ�"
	hsvcheck = CreateWindow(
		L"BUTTON",
		L"�I�����Ɋw�K��Ԃ�ۑ�",
		WS_CHILD
			| WS_VISIBLE | BS_AUTOCHECKBOX,
		0, 304,
		200, 34,
		hwnd,
		reinterpret_cast<HMENU>(SVCHECKBOX_ID),
		hInstance,
		NULL
	);
	OrgPrc_SvCheckBox = reinterpret_cast<FARPROC>(GetWindowLongPtr(hsvcheck, GWL_WNDPROC));
	if(!SetWindowLongPtr(
			hsvcheck,
			GWL_WNDPROC,
			reinterpret_cast<LONG_PTR>(OrgPrc_SvCheckBox)
	)){
		return 0;
	}
	SendMessage(
		hsvcheck,
		BM_SETCHECK,
		config.svcheck ? BST_CHECKED : BST_UNCHECKED,
		0
	);
	#pragma endregion

	ShowWindow(hwnd, SW_SHOW);

	MSG msg;
	while(GetMessage(&msg, NULL, 0, 0) > 0){
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return 0;
}
