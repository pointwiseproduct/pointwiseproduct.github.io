#include <iostream>
#include <deque>
#include <set>
#include <utility>
#include <fstream>
#include <boost/random.hpp>
#include <boost/preprocessor/repeat.hpp>
#include <boost/preprocessor/seq.hpp>
#include <boost/preprocessor/punctuation/comma_if.hpp>
#include <boost/preprocessor/cat.hpp>
#include <tty/quick_search.hpp>
#include <tty/lcsubsequence.hpp>

namespace strmorph{
	//��b�̃��O��ێ��A�����ΏۂƂ����������s��
	class log_t{
		//---------- �^

		//---------- �����o
		//���O�ێ���
	private:
		static const int sentence_length = 512;

		//���O�̒��g  ���낢��
	private:
		std::deque<sentence_t> sentence; //���͂̐��f�[�^
		std::deque<morph_sequence_t> morph_sequence; //�`�ԑf��͂��ꂽ�f�[�^

		//�����p�̃����o
	private:
		tty::quick_search<wchar_t> xsearch;
		tty::lcsubsequence<int> xlcs;

		//---------- �����o�֐�
		//���𓾂�
	public:
		sentence_t &get_sentence(const int &a){
			return sentence[a];
		}
		const sentence_t &get_sentence(const int &a) const{
			return sentence[a];
		}

		//�`�ԑf��𓾂�
	public:
		morph_sequence_t &get_morph_sequence(const int &a){
			return morph_sequence[a];
		}
		const morph_sequence_t &get_morph_sequence(const int &a) const{
			return morph_sequence[a];
		}

		//operator []
	public:
#define twrite(s) \
	mwrite(tname_b, const_b, lwrite_b, s) mwrite(tname_a, const_a, lwrite_a, s) \
	fwrite(tname_a, const_t, s) fwrite(tname_b, const_u, s)

#define mwrite(tn, cx, lw, s) \
		struct tn(){ hwrite(cx, s) cwrite(tn, cx, s) ccwrite(tn, s) lw(s) };

#define hwrite(cx, s) \
	BOOST_PP_REPEAT(BOOST_PP_SEQ_SIZE(s), hwrite_i, (cx)(s))

#define hwrite_i(z, i, data) \
	BOOST_PP_SEQ_ELEM(0, data)(BOOST_PP_CAT(BOOST_PP_SEQ_ELEM(i, BOOST_PP_SEQ_ELEM(1, data)), _t)) \
		&BOOST_PP_SEQ_ELEM(i, BOOST_PP_SEQ_ELEM(1, data));

#define cwrite(tn, cx, s) \
	tn()( \
		BOOST_PP_REPEAT(BOOST_PP_SEQ_SIZE(s), cwrite_i, (cx)(s)) \
	) : BOOST_PP_REPEAT(BOOST_PP_SEQ_SIZE(s), cwrite_ii, s) {}

#define cwrite_i(z, i, data) \
	BOOST_PP_COMMA_IF(i) \
		BOOST_PP_SEQ_ELEM(0, data)(BOOST_PP_CAT(BOOST_PP_SEQ_ELEM(i, BOOST_PP_SEQ_ELEM(1, data)), _t)) \
			&BOOST_PP_CAT(BOOST_PP_SEQ_ELEM(i, BOOST_PP_SEQ_ELEM(1, data)), _)

#define cwrite_ii(z, i, data) \
	BOOST_PP_COMMA_IF(i) \
		BOOST_PP_SEQ_ELEM(i, data) ( BOOST_PP_CAT(BOOST_PP_SEQ_ELEM(i, data), _) )

#define ccwrite(tn, s) \
	tn()(const tn() &obj) : \
		BOOST_PP_REPEAT(BOOST_PP_SEQ_SIZE(s), ccwrite_i, s) \
	{}

#define ccwrite_i(z, i, data) \
	BOOST_PP_COMMA_IF(i) BOOST_PP_SEQ_ELEM(i, data) (obj.BOOST_PP_SEQ_ELEM(i, data))

#define fwrite(tn, cy, s) \
	inline tn() operator [](int idx) cy(){ return tn()(owrite(s)); }

#define owrite(s) \
	BOOST_PP_REPEAT(BOOST_PP_SEQ_SIZE(s), owrite_i, s)

#define owrite_i(z, i, data) \
	BOOST_PP_COMMA_IF(i) BOOST_PP_SEQ_ELEM(i, data)[idx]

#define lwrite_a(s) \
	operator const_logelem_t() const{ return const_logelem_t(lwrite_a_i(s)); }

#define lwrite_a_i(s) \
	BOOST_PP_REPEAT(BOOST_PP_SEQ_SIZE(s), lwrite_a_ii, s)

#define lwrite_a_ii(z, i, data) \
	BOOST_PP_COMMA_IF(i) BOOST_PP_SEQ_ELEM(i, data)

#define lwrite_b(s) /* eat */
#define tname_a() logelem_t
#define tname_b() const_logelem_t
#define const_a(a) a
#define const_b(a) const a
#define const_t() /* empty */
#define const_u() const

		/*
			//�v�f�ւ̎Q�Ƃ�ێ�����
			struct logelem_t{
				sentence_t &sentence;
				morph_sequence_container_t &morph_sequence;
				:
				:

				...�R���X�g���N�^�Ȃǂ͏ȗ�...
			};

			//operator []
			inline logelem_t operator [](int idx){ return logelem_t(...) }

			//const�o�[�W����������
			struct const_logelem_t{...};
			inline const_logelem_t operator [](int idx) const{...}
		*/

		twrite((sentence)(morph_sequence));

#undef twrite
#undef mwrite
#undef hwrite
#undef hwrite_i
#undef cwrite
#undef cwrite_i
#undef cwrite_ii
#undef ccwrite
#undef ccwrite_i
#undef fwrite
#undef owrite
#undef owrite_i
#undef lwrite_a
#undef lwrite_a_i
#undef lwrite_a_ii
#undef lwrite_b
#undef tname_a
#undef tname_b
#undef const_a
#undef const_b
#undef const_t
#undef const_u

		//�L���͈͂𓾂�
		int useful_range() const{
			return static_cast<int>(sentence.size());
		}

		//write
		void write() const{
			std::fstream f(datafilepath.log().char_str(), std::ios::out | std::ios::binary);
			int tmp = useful_range();

			//useful_range
			f.write(reinterpret_cast<const char*>(&tmp), sizeof(int));

			for(int i = 0; i < useful_range(); ++i){
				//sentence
				tmp = sentence[i].length();
				f.write(reinterpret_cast<const char*>(&tmp), sizeof(int));
				f.write(
					reinterpret_cast<const char*>(sentence[i].get()),
					static_cast<std::streamsize>(tmp * sizeof(wchar_t))
				);

				//morph_sequence
				tmp = morph_sequence[i].length;
				f.write(reinterpret_cast<const char*>(&tmp), sizeof(int));
				f.write(
					reinterpret_cast<const char*>(morph_sequence[i].data),
					static_cast<std::streamsize>(tmp * sizeof(int))
				);
			}
		}

		//read
		bool read(){
			std::fstream f(datafilepath.log().char_str(), std::ios::in | std::ios::binary);
			if(f.fail()) return false;

			int tmp, ur;
			std::vector<wchar_t> v;
			std::vector<int> msv;
			v.reserve(0xFF);
			msv.reserve(0xFF);

			//useful_range
			f.read(reinterpret_cast<char*>(&ur), sizeof(int));

			for(int i = 0; i < ur; ++i){
				//sentence
				f.read(reinterpret_cast<char*>(&tmp), sizeof(int));
				v.resize(tmp + 1);
				f.read(
					reinterpret_cast<char*>(&v[0]),
					static_cast<std::streamsize>(tmp * sizeof(wchar_t))
				);
				v[v.size() - 1] = 0;
				sentence.push_back(sentence_t());
				sentence.back().set(&v[0]);

				//morph_sequence
				f.read(reinterpret_cast<char*>(&tmp), sizeof(int));
				msv.resize(tmp);
				f.read(
					reinterpret_cast<char*>(&msv[0]),
					static_cast<std::streamsize>(tmp * sizeof(int))
				);
				morph_sequence.push_back(morph_sequence_t());
				morph_sequence.back().length = tmp;
				morph_sequence.back().data = new int[tmp];
				std::memcpy(
					reinterpret_cast<void*>(morph_sequence.back().data),
					reinterpret_cast<void*>(&msv[0]),
					tmp * sizeof(int)
				);
			}

			return true;
		}

		//���͂Ɖ��
		void in(const wchar_t *str){
			if((useful_range() + 1) == sentence_length){
				sentence.pop_back();
				morph_sequence.pop_back();
			}

			sentence.push_front(sentence_t());
			morph_sequence.push_front(morph_sequence_t());

			sentence[0].set(str);
			search_nmorph(0);
			morph_analyze(0);
			connect_morph_sequence(0);
			connect_connectionmap(0);
			search_idiom(0);
		}

		//����
		void out(boost::mt19937 &gen, std::wstring &str){			
			create_sentence_result_t result;
			bool flag = false;
			str.clear();

			if(gen() % 8 == 0) flag = create_sentence_idiom(gen, result);
			if(!flag){
				flag = create_sentence_mt(gen, result);
			}

			if(flag){
				for(
					create_sentence_result_t::const_iterator
						it = result.begin(), end = result.end();
					it != end;
					++it
				){
					const dic_t::idmap_value_t &iv(dic.find(*it));
					str += std::wstring(*iv.ptr_key->str, iv.ptr_key->length);
				}
			}else{
				str.assign(L"�i���Ɍ������͂Ȃ��݂����ł�...�j");
			}
		}

		//search_nmorph()�p�̃T�u�V�[�P���X
		//��������ƉE�������ێ�����
		struct subsequence_str_t{
			const wchar_t *str, *o;
			int length, olength;

			//POD�������ɂ����̂ŃR���X�g���N�^�͂Ȃ���
			static subsequence_str_t create(const wchar_t *s, int l){
				subsequence_str_t r;
				r.o = r.str = s;
				r.olength = r.length = l;
				return r;
			}

			static subsequence_str_t create(const wchar_t *s, int l, int orgl){
				subsequence_str_t r;
				r.o = r.str = s;
				r.length = l;
				r.olength = orgl;
				return r;
			}

			static subsequence_str_t create(const wchar_t *s, const wchar_t *org, int l, int ol){
				subsequence_str_t r;
				r.str = s;
				r.o = org;
				r.length = l;
				r.olength = ol;
				return r;
			}
		};

		typedef std::deque<subsequence_str_t> subsequence_queue_t;

		//�ʂ�sentence�Ɣ�r���Ď����ɖ����`�ԑf�����o���鑍����̖��m�P��T��
		//[idx] ��͑Ώۂ̃��O
		void search_nmorph(int idx){
			if(useful_range() < 2) return;

			static subsequence_queue_t subsequence_queue;
			subsequence_queue.clear();

			subsequence_queue.push_front(
				subsequence_str_t::create(
					sentence[idx].get(),
					sentence[idx].length()
				)
			);

			for(; subsequence_queue.size() != 0; ){
				subsequence_str_t subseq = subsequence_queue.front();
				subsequence_queue.pop_front();

				xsearch.preprocess(subseq.str, subseq.length);

				for(int i = 0, e = useful_range(); i < e; ++i){
					if(i == idx) continue;

					int result;
					if((result = xsearch.search(sentence[i].get(), sentence[i].length())) < 0){
						continue;
					}

					//���������炵���̂Ŏ����ɒǉ�
					dic_t::insert_result_t insert_result = dic.insert(subseq.str, subseq.length);
					if(insert_result.second){
						//���������Ƃ��̓��ʂȏ���
					}

					//�܂���͂��ĂȂ��������queue�ɒǉ�����
					//��������
					if(subseq.str != subseq.o){
						int tmp_0 = static_cast<int>(subseq.str - subseq.o);
						int tmp_1 = (std::min)(tmp_0, subseq.length - 1);
						if(tmp_1 > 1)
							subsequence_queue.push_front(
								subsequence_str_t::create(
									subseq.o,
									tmp_1,
									static_cast<int>(subseq.str - subseq.o)
								)
							);
					}
					//�E������
					{
						int tmp;
						if((tmp = static_cast<int>((subseq.o + subseq.olength) - (subseq.str + subseq.length))) >= 1)
							subsequence_queue.push_front(
								subsequence_str_t::create(subseq.str + subseq.length, tmp)
							);
					}

					goto search_success; //goto�g���ĉ�������
				}

				//������܂���ł���...
				//search_fail:;
				{
					if((subseq.str + subseq.length) < (subseq.o + subseq.olength)){
						//���炷
						subsequence_queue.push_front(
							subsequence_str_t::create(
								subseq.str + 1,
								subseq.o,
								subseq.length,
								subseq.olength
							)
						);
					}else if(subseq.length != 1){
						//�k�߂Ďn�߂����蒼��
						subsequence_queue.push_front(
							subsequence_str_t::create(
								subseq.o,
								subseq.length - 1,
								subseq.olength
							)
						);
					}

					continue;
				}

				//��������
				//������Ȃɂ�����Ƃ����̂�...
				search_success:;
				continue;
			}
		}

		//dic��find�����Ă���������̉��
		//[result] ����Ɍ��ʂ��i�[����
		//[idx]    ��͑Ώۂ̃��O
		void morph_analyze(morph_sequence_container_t &result, int idx){
			if(useful_range() < 1) return;

			static subsequence_queue_t subsequence_queue;
			const wchar_t *const ptr = sentence[idx].get();
			const int length = sentence[idx].length();
			result.clear();
			subsequence_queue.clear();

			dic_t::key_t key = dic_t::key_t::create_virtual(NULL, 0);
			subsequence_str_t subsequence_str;
			dic_t::iterator it;

			subsequence_queue.push_front(
				subsequence_str_t::create(ptr, length)
			);

			for(; subsequence_queue.size() != 0; ){
				subsequence_str = subsequence_queue.front();
				subsequence_queue.pop_front();

				if(subsequence_str.length < 2){
					dic_t::insert_result_t insert_result = dic.insert(subsequence_str.o, subsequence_str.olength);
					result[
						static_cast<int>(subsequence_str.o - ptr)
					] = insert_result.first->second.id;

					continue;
				}

				*key.str = subsequence_str.str;
				key.length = subsequence_str.length;
				it = dic.find(key);

				if(it == dic.end()){ //������܂���ł���...
					if(
						(subsequence_str.str + subsequence_str.length) ==
						(subsequence_str.o + subsequence_str.olength)
					){
						if(subsequence_str.length == 2){
							//���m�̒P��Ƃ��ď���������
							dic_t::insert_result_t insert_result = dic.insert(subsequence_str.o, subsequence_str.olength);
							result[
								static_cast<int>(subsequence_str.o - ptr)
							] = insert_result.first->second.id;
						}else{
							subsequence_queue.push_front(
								subsequence_str_t::create(
									subsequence_str.o,
									subsequence_str.o,
									subsequence_str.length - 1,
									subsequence_str.olength
								)
							);
						}
					}else{
						subsequence_queue.push_front(
							subsequence_str_t::create(
								subsequence_str.str + 1,
								subsequence_str.o,
								subsequence_str.length,
								subsequence_str.olength
							)
						);
					}
				}else{ //������܂���...
					result[
						static_cast<int>(subsequence_str.str - ptr)
					] = it->second.id;

					//��������
					if(subsequence_str.str != subsequence_str.o){
						int
							ol = static_cast<int>(subsequence_str.str - subsequence_str.o),
							l = subsequence_str.length - 1;

						subsequence_queue.push_front(
							subsequence_str_t::create(
								subsequence_str.o, (std::min)(ol, l), ol
							)
						);
					}
					//�E������
					{
						int tmp;
						if((tmp = static_cast<int>((subsequence_str.o + subsequence_str.olength) - (subsequence_str.str + subsequence_str.length))) > 0){
							subsequence_queue.push_front(
								subsequence_str_t::create(subsequence_str.str + subsequence_str.length, tmp)
							);
						}
					}
				}
			}

			dic_t::key_t::destroy_virtual(key);
		}

		struct idiom_holder{
			dic_t::idiom_t idiom;
			int score;
			bool flag;
		};

		//���p�I�p�@��T���Ď����ɓ����
		//idx���O�̃��O�Əƍ�����
		void search_idiom(int idx){
			static const int threshold_lub = 1, threshold_ldb = 3;

			typedef std::deque<idiom_holder> im_t;
			static im_t im;

			//im�̒��g�������ŊJ��
			struct im_dtor_t{
				const im_t &im;

				im_dtor_t(im_t &im_) : im(im_){}

				~im_dtor_t(){
					for(int i = 0, e = static_cast<int>(im.size()); i < e; ++i){
						im[i].idiom.destruction();
					}
				}
			};

			static im_dtor_t im_dtor(im);

			static int threshold = threshold_lub;
			struct f{
				//臒l�̒���
				inline static int adj(int x, int y, int threshold){
					//if(x == 0) return threshold;
					//int a = static_cast<int>(static_cast<float>(y) / static_cast<float>(x));
					//if(a > threshold_ldb){
					//	threshold -= (a - threshold_ldb) / 2 + 1;
					//	if(threshold < 1) threshold = 0;
					//	std::cout << "          <" << x << "/" << y << ">" << std::endl;
					//}else if(a < threshold_lub){
					//	threshold += a / 2 + 1;
					//	std::cout << "          [" << x << "/" << y << "]" << std::endl;
					//}

					return threshold;
				}

				inline static void check(idiom_holder &a, int threshold, int &addeded){
					//�ǉ������v�f��臒l����������
					if(a.score >= (threshold - 1)){
						//�����ɒǉ�
						dic_t::idiom_t nidiom = a.idiom.copy();
						dic_t::insert_idiom_result_t idr = dic.insert_idiom(nidiom);

						//�e�P��̃}�b�v���X�V����
						for(int k = 0; k < nidiom.length; ++k){
							dic_t::idmap_value_t &iv(dic.find(nidiom.data[k]));
							dic_t::data_t::idiomconnectionmap_t idiomconnectionmap(iv.ptr_data->compressed_idiomconnectionmap);

							idiomconnectionmap.insert(idr.id);
							/*
							int &s(idiomconnectionmap.data[idiomconnectionmap.length - 1].score);
							if(s){
								s += a.score - 1;
							}else{
								s += a.score;
							}
							*/
							idiomconnectionmap.encode(iv.ptr_data->compressed_idiomconnectionmap);
						}

						if(idr.result_flag){
							a.flag = true;
							++addeded;
						}else{
							nidiom.destruction();
						}
					}
				}
			};

			int added = 0;
			static int addeded = 0;

			//�ǂ����Ă�臒l�ɒB���Ȃ��悤�Ȃ�T�����������ċA��
			if(useful_range() < threshold_lub){
				for(int i = idx + 1, e = useful_range() - idx; i < e; ++i){
					dic_t::idiom_t idiom = xlcs.search(
						morph_sequence[idx].data, morph_sequence[idx].length,
						morph_sequence[i].data, morph_sequence[i].length
					);

					if(idiom.length < 3){
						idiom.destruction();
						continue;
					}

					idiom_holder a;
					a.idiom = idiom;
					a.score = 0;
					a.flag = false;
					im.push_front(a);
					++added;
				}

				return;
			}

			//�T��
			for(int i = idx + 1, e = useful_range() - idx; i < e; ++i){
				dic_t::idiom_t idiom = xlcs.search(
					morph_sequence[idx].data, morph_sequence[idx].length,
					morph_sequence[i].data, morph_sequence[i].length
				);

				if(idiom.length < 3){
					idiom.destruction();
					continue;
				}

				//�ƍ�
				{
					idiom_holder a;
					bool flag = false;
					for(int j = 0, je = static_cast<int>(im.size()); j < je; ++j){
						if(im[j].idiom == idiom){
							flag = true;

							a.idiom = idiom;
							a.flag = false;
							a.score = im[j].score + 1;
							im.push_front(a);
							++added;

							break;
						}
					}

					if(!flag){
						a.idiom = idiom;
						a.flag = false;
						a.score = 0;
						im.push_front(a);
						++added;
					}

					//����
					f::check(im.front(), threshold, addeded);
					//����
					{
						int tmp = threshold;
						threshold = f::adj(addeded, static_cast<int>(im.size()), threshold);
						if(threshold < tmp && im.front().score < tmp) f::check(im.front(), threshold, addeded); //�ĕ]��
					}

					break;
				}
			}

			//������΍폜
			for(; im.size() > sentence_length; ){
				if(im.back().flag){
					--addeded;
				}
				im.back().idiom.destruction();
				im.pop_back();
			}
		}

		//result�w�肪�Ȃ��ꍇ�̓��O�ɓ����
		void morph_analyze(int idx){
			morph_sequence_container_t result;
			morph_analyze(result, idx);
			morph_sequence[idx] = morph_sequence_container2pod(result);
		}

		//�`�ԑf�V�[�P���X�����ɒP��}�b�v��ڑ�����
		void connect_morph_sequence(const morph_sequence_t &a){
			if(a.length < 2) return;

			for(int i = 0; i < (a.length - 1); ++i){
				//�J�ڃ}�b�v
				dic_t::idmap_value_t &iv_a(dic.find(a.data[i]));
				dic_t::data_t::transitionmap_t transitionmap(iv_a.ptr_data->compressed_transitionmap);
				transitionmap.insert(a.data[i + 1]);
				transitionmap.encode(iv_a.ptr_data->compressed_transitionmap);

				//�t�J�ڃ}�b�v
				dic_t::idmap_value_t &iv_b(dic.find(a.data[i + 1]));
				dic_t::data_t::reverse_transitionmap_t reverse_transitionmap(iv_b.ptr_data->compressed_reverse_transitionmap);
				reverse_transitionmap.insert(a.data[i]);
				reverse_transitionmap.encode(iv_b.ptr_data->compressed_reverse_transitionmap);

				//�֘A�}�b�v
				dic_t::data_t::connectionmap_t
					connenctionmap_a(iv_a.ptr_data->compressed_connectionmap),
					connenctionmap_b(iv_b.ptr_data->compressed_connectionmap);
				connenctionmap_a.insert(a.data[i + 1]);
				connenctionmap_b.insert(a.data[i]);
				connenctionmap_a.encode(iv_a.ptr_data->compressed_connectionmap);
				connenctionmap_b.encode(iv_b.ptr_data->compressed_connectionmap);
			}

			//�n�[�Ɛ擪������
			dic_t::idmap_value_t &iv_a(dic.find(a.data[0]));
			dic_t::data_t::reverse_transitionmap_t reverse_transitionmap(iv_a.ptr_data->compressed_reverse_transitionmap);
			reverse_transitionmap.insert(dic_t::data_t::reverse_transitionmap_t::nil);
			reverse_transitionmap.encode(iv_a.ptr_data->compressed_reverse_transitionmap);

			//�I�[�ƍŌ��������
			dic_t::idmap_value_t &iv_b(dic.find(a.data[a.length - 1]));
			if((*iv_b.ptr_key->str)[iv_b.ptr_key->length - 1] != L'�A'){
				dic_t::data_t::transitionmap_t transitionmap(iv_b.ptr_data->compressed_transitionmap);
				transitionmap.insert(dic_t::data_t::transitionmap_t::nil);
				transitionmap.encode(iv_b.ptr_data->compressed_transitionmap);
			}
		}

		void connect_morph_sequence(int idx){
			connect_morph_sequence(morph_sequence[idx]);
		}

		//�`�ԑf�V�[�P���X�����ɒP��}�b�v��ؒf����
		void disconnect_morph_sequence(const morph_sequence_t &a){
			for(int i = 0; i < (a.length - 1); ++i){
				//�J�ڃ}�b�v
				dic_t::idmap_value_t &iv_a(dic.find(a.data[i]));
				dic_t::data_t::transitionmap_t transitionmap(iv_a.ptr_data->compressed_transitionmap);
				transitionmap.insert(a.data[i + 1]);
				transitionmap.encode(iv_a.ptr_data->compressed_transitionmap);

				//�t�J�ڃ}�b�v
				dic_t::idmap_value_t &iv_b(dic.find(a.data[i + 1]));
				dic_t::data_t::reverse_transitionmap_t reverse_transitionmap(iv_b.ptr_data->compressed_reverse_transitionmap);
				reverse_transitionmap.insert(a.data[i]);
				reverse_transitionmap.encode(iv_b.ptr_data->compressed_reverse_transitionmap);

				//�֘A�}�b�v
				dic_t::data_t::connectionmap_t
					connenctionmap_a(iv_a.ptr_data->compressed_connectionmap),
					connenctionmap_b(iv_b.ptr_data->compressed_connectionmap);
				connenctionmap_a.erase(connenctionmap_a.find(a.data[i + 1]));
				connenctionmap_b.erase(connenctionmap_b.find(a.data[i]));
				connenctionmap_a.encode(iv_a.ptr_data->compressed_connectionmap);
				connenctionmap_b.encode(iv_b.ptr_data->compressed_connectionmap);
			}
		}

		void disconnect_morph_sequence(int idx){
			disconnect_morph_sequence(morph_sequence[idx]);
		}

		//�`�ԑf���㉺�̃��O�Ɛڑ�����
		void connect_connectionmap(int idx){
			dic_t::data_t::connectionmap_t *a = new dic_t::data_t::connectionmap_t[morph_sequence[idx].length];
			for(int i = 0; i < morph_sequence[idx].length; ++i){
				dic_t::idmap_value_t &iv_a(dic.find(morph_sequence[idx].data[i]));
				new(&a[i]) dic_t::data_t::connectionmap_t(iv_a.ptr_data->compressed_connectionmap);
			}

			//�㉺�̃��O�Ō݂��ɐڑ�����
			for(int bln = 0; bln < 2; ++bln){
				int aln = bln - ((bln + 1) & 1) + idx;

				if(idx != ((useful_range() - 1) * bln)){
					dic_t::data_t::connectionmap_t *b = new dic_t::data_t::connectionmap_t[morph_sequence[aln].length];
					for(int i = 0; i < morph_sequence[aln].length; ++i){
						dic_t::idmap_value_t &iv_b(dic.find(morph_sequence[aln].data[i]));
						new(&b[i]) dic_t::data_t::connectionmap_t(iv_b.ptr_data->compressed_connectionmap);
					}

					for(int i = 0; i < morph_sequence[idx].length; ++i){
						for(int j = 0; j < morph_sequence[aln].length; ++j){
							//insert
							a[i].insert(morph_sequence[aln].data[j]);
							b[j].insert(morph_sequence[idx].data[i]);

							//encode
							b[j].encode(dic.find(morph_sequence[aln].data[j]).ptr_data->compressed_connectionmap);
						}
					}

					delete[] b;
				}
			}

			//encode
			for(int i = 0; i < morph_sequence[idx].length; ++i){
				dic_t::idmap_value_t &iv_a(dic.find(morph_sequence[idx].data[i]));
				a[i].encode(iv_a.ptr_data->compressed_connectionmap);
			}

			delete[] a;
		}

		////�`�ԑf���㉺�̃��O�Ɛؒf����
		//void disconnect_connectionmap(int idx){
		//	dic_t::data_t::connectionmap_t *a = new dic_t::data_t::connectionmap_t[morph_sequence[idx].length];
		//	for(int i = 0; i < morph_sequence[idx].length; ++i){
		//		dic_t::idmap_value_t &iv_a(dic.find(morph_sequence[idx].data[i]));
		//		new(&a[i]) dic_t::data_t::connectionmap_t(iv_a.ptr_data->compressed_connectionmap);
		//	}

		//	//�㉺�̃��O�Ō݂��ɐؒf����
		//	for(int bln = 0; bln < 2; ++bln){
		//		int aln = bln - ((bln + 1) & 1) + idx;

		//		if(idx != ((useful_range() - 1) * bln)){
		//			dic_t::data_t::connectionmap_t *b = new dic_t::data_t::connectionmap_t[morph_sequence[aln].length];
		//			for(int i = 0; i < morph_sequence[aln].length; ++i){
		//				dic_t::idmap_value_t &iv_b(dic.find(morph_sequence[aln].data[i]));
		//				new(&b[i]) dic_t::data_t::connectionmap_t(iv_b.ptr_data->compressed_connectionmap);
		//			}

		//			for(int i = 0; i < morph_sequence[idx].length; ++i){
		//				for(int j = 0; j < morph_sequence[aln].length; ++j){
		//					//erase
		//					a[i].erase(a[i].find(morph_sequence[aln].data[j]));
		//					b[j].erase(b[j].find(morph_sequence[idx].data[i]));

		//					//encode
		//					b[j].encode(dic.find(morph_sequence[aln].data[j]).ptr_data->compressed_connectionmap);
		//				}
		//			}

		//			delete[] b;
		//		}
		//	}

		//	//encode
		//	for(int i = 0; i < morph_sequence[idx].length; ++i){
		//		dic_t::idmap_value_t &iv_a(dic.find(morph_sequence[idx].data[i]));
		//		a[i].encode(iv_a.ptr_data->compressed_connectionmap);
		//	}

		//	delete[] a;
		//}

		//�֘A����P������̃R���e�i�ɂ܂Ƃ߂�
		//create_sentence�Ŏg���Ă���
		typedef std::map<int, int> connectionelement_t; //score, id
		typedef std::set<dic_t::data_t::idiomconnectionmap_t::element_t> connectionidiom_t;

		//�֘A����P��Ɗ��p��I�p�@���܂Ƃ߂�
		//�֘A�}�b�v�G�������g�̗݌v�X�R�A��Ԃ�
		//create_sentence�Ŏg���Ă���
		int collect_connectionelement(connectionelement_t &connectionelement, connectionidiom_t &connectionidiom, int idx) const{
			int r = 0;
			std::deque<int> dnc;
			//�ꎟ
			for(int i = 0; i < morph_sequence[idx].length; ++i){
				const dic_t::idmap_value_t &iv(dic.find(morph_sequence[idx].data[i]));
				for(
					dic_t::data_t::connectionmap_t::compressed_iterator cit(iv.ptr_data->compressed_connectionmap);
					cit != cit.end();
					++cit
				){
					r += (*cit).score;
					connectionelement.insert(connectionelement_t::value_type((*cit).score, (*cit).dst_id));
					dnc.push_back((*cit).dst_id);
				}

				for(
					dic_t::data_t::idiomconnectionmap_t::compressed_iterator cit(iv.ptr_data->compressed_idiomconnectionmap);
					cit != cit.end();
					++cit
				){
					connectionidiom.insert(*cit);
				}
			}

			//��
			for(
				std::deque<int>::iterator it = dnc.begin(), end = dnc.end();
				it != end;
				++it
			){
				const dic_t::idmap_value_t &iv(dic.find(*it));
				for(
					dic_t::data_t::connectionmap_t::compressed_iterator cit(iv.ptr_data->compressed_connectionmap);
					cit != cit.end();
					++cit
				){
					r += (*cit).score;
					connectionelement.insert(connectionelement_t::value_type((*cit).score, (*cit).dst_id));
				}

				for(
					dic_t::data_t::idiomconnectionmap_t::compressed_iterator cit(iv.ptr_data->compressed_idiomconnectionmap);
					cit != cit.end();
					++cit
				){
					connectionidiom.insert(*cit);
				}
			}

			return r;
		}

		//idiom���g���ĕ��𐶐�����
		//���������Ȃ�true, ���s�����Ȃ�false��Ԃ�
		typedef std::deque<int> create_sentence_result_t;
		bool create_sentence_idiom(boost::mt19937 &gen, create_sentence_result_t &result){
			struct fn{
				//idiom�̒���id�Ɠ����P�ꂪ���邩�ǂ���
				inline static bool idiom_id_test(const dic_t::idiom_t &idiom, int id){
					for(int i = 0; i < idiom.length; ++i){
						if(idiom.data[i] == id) return true;
					}
					return false;
				}

				//src�̑J�ڐ��dst���܂܂�Ă��Ȃ����ǂ���
				inline static bool transitionmap_test(int src, int dst){
					dic_t::idmap_value_t &iv(dic.find(src));
					dic_t::data_t::transitionmap_t::compressed_iterator
						cit(iv.ptr_data->compressed_transitionmap);

					for(; cit != cit.end(); ++cit){
						if((*cit).dst_id == dst) return false;
					}

					return true;
				}
			};

			connectionelement_t connectionelement;
			connectionidiom_t connectionidiom;

			int i,
				cumulative_score = 0,
				rndval;
			create_sentence_result_t &idstr(result);

			for(i = 0; i < useful_range(); ++i){
				if(morph_sequence[i].uf) continue;

				std::size_t pr_connectionidiom_size = connectionidiom.size();
				cumulative_score += collect_connectionelement(connectionelement, connectionidiom, i);
				std::size_t
					connectionidiom_size = connectionidiom.size(),
					connectionelement_size = connectionelement.size();

				if((connectionidiom_size == 0) || (connectionelement_size == 0)) continue;

				//�g�p����idiom�����߂�
				//�ēx���߂�Ƃ��͂����ɖ߂��Ă���
			select_idiom:;
				rndval = static_cast<int>(gen() % connectionidiom_size);
				connectionidiom_t::iterator idiom_it = connectionidiom.begin();
				for(int j = 0; j < rndval; ++j){
					++idiom_it;
				}
				--connectionidiom_size;
				const dic_t::idiom_t &idiom(dic.find_idiom(idiom_it->idiom_id));
				connectionidiom.erase(idiom_it);
				idstr.clear();

				//�n�[����������
				{
					bool flag = false;
					dic_t::idmap_value_t &iv(dic.find(idiom.data[0]));
					dic_t::data_t::reverse_transitionmap_t::compressed_iterator
						cit(iv.ptr_data->compressed_reverse_transitionmap);
					for(; cit != cit.end(); ++cit){
						if((*cit).src_id == dic_t::data_t::reverse_transitionmap_t::nil){
							flag = true;
							break;
						}
					}

					if(!flag){
						//reverse_transitionmap����n�[�ɂȂ蓾��P���H��
						cit = cit.begin();
						std::deque<int> candidate;

						for(; cit != cit.end(); ++cit){
							dic_t::data_t::reverse_transitionmap_t::compressed_iterator
								ccit(dic.find((*cit).src_id).ptr_data->compressed_reverse_transitionmap);
							for(; ccit != ccit.end(); ++ccit){
								if((*ccit).src_id == dic_t::data_t::reverse_transitionmap_t::nil){
									candidate.push_back((*cit).src_id);
									break;
								}
							}
						}

						if(candidate.size() == 0){
							if(connectionidiom_size)
								goto select_idiom;
							else
								goto fail;
						}

						idstr.push_back(candidate[gen() % candidate.size()]);
					}
				}

				//chain���l������������
				{
					std::deque<int> candidate;
					for(int j = 0; j < (idiom.length - 1); ++j){
						idstr.push_back(idiom.data[j]);
						if(!idiom.chain[j]){ //�A���ɕK�v�ȒP���������
							connectionelement_t::const_iterator it, end;
							int tmp;
							for(
								it = connectionelement.begin(), end = connectionelement.end();
								it != end;
								++it
							){
								tmp = it->second;
								if(fn::idiom_id_test(idiom, tmp)) continue; //�P�ꂪidiom���Ɋ��ɑ��݂���Ȃ��蒼��
								if(fn::transitionmap_test(idiom.data[j], tmp)) continue; //���A�����ĂȂ��Ȃ��蒼��
								if(fn::transitionmap_test(tmp, idiom.data[j + 1])) continue; //�E�A�����ĂȂ��Ȃ��蒼��
								candidate.push_back(tmp);
							}

							if(it == end){
								if(connectionidiom_size)
									goto select_idiom;
								else
									goto fail;
							}

							idstr.push_back(candidate[gen() % candidate.size()]);
						}
					}
				}

				//�I�[����������
				idstr.push_back(idiom.data[idiom.length - 1]);
				for(; ; ){
					dic_t::idmap_value_t &iv(dic.find(idstr.back()));

					//�I�[�Ƃ��đ��������Ȃ�break
					if(!fn::transitionmap_test(iv.ptr_data->id, dic_t::data_t::transitionmap_t::nil)){
						break;
					}

					//�I�[�ɂȂ蓾��P���T��
					std::deque<int> candidate;
					dic_t::data_t::reverse_transitionmap_t::compressed_iterator
						cit(iv.ptr_data->compressed_transitionmap);
					for(; cit != cit.end(); ++cit){
						int tmp = (*cit).src_id;
						if(!fn::transitionmap_test(tmp, dic_t::data_t::transitionmap_t::nil)){
							candidate.push_back(tmp);
						}
					}

					if(candidate.size() == 0){
						if(connectionidiom_size)
							goto select_idiom;
						else
							goto fail;
					}

					idstr.push_back(candidate[gen() % candidate.size()]);
				}

				morph_sequence[i].uf = true;
				break;

			fail:; //�������s�A�Ď{�s�Ȃ炱���ɔ��
				morph_sequence[i].uf = true;
			}

			//�������s
			if(i == useful_range()){
				result.clear();
				return false;
			}else{
				return true;
			}
		}

		//�}���R�t�J�ڂŕ��𐶐�����
		bool create_sentence_mt(boost::mt19937 &gen, create_sentence_result_t &result){
			struct fn{
				inline static bool ttest(int id){
					dic_t::idmap_value_t &iv(dic.find(id));
					dic_t::data_t::transitionmap_t::compressed_iterator
						cit(iv.ptr_data->compressed_transitionmap);
					dic_t::data_t::transitionmap_t::compressed_iterator
						cend = cit.end();

					for(; cit != cend; ++cit){
						if((*cit).dst_id == dic_t::data_t::transitionmap_t::nil)
							return true;
					}

					return false;
				}
			};

			//�J�ڎ����T��
			std::deque<int> candidate;
			for(int mscnt = 0; mscnt < useful_range(); ++mscnt){
				for(int i = 0, e = morph_sequence[mscnt].length; i < e; ++i){
					const int *a = morph_sequence[mscnt].data;
					dic_t::idmap_value_t &iv(dic.find(a[i]));
					dic_t::data_t::reverse_transitionmap_t::compressed_iterator
						cit(iv.ptr_data->compressed_reverse_transitionmap);
					dic_t::data_t::reverse_transitionmap_t::compressed_iterator
						cend = cit.end();

					for(; cit != cend; ++cit){
						if((*cit).src_id == dic_t::data_t::reverse_transitionmap_t::nil)
							candidate.push_back(a[i]);
					}
				}

				if(candidate.size() < 3) continue;
				break;
			}

			if(candidate.size() == 0) false;
			int next = candidate[gen() % candidate.size()]; //�J�ڎ�

			//�����_���ɕ��𐶐�����
			for(int mscnt = 0; mscnt < (morph_sequence[0].length * 2); ++mscnt){
				result.push_back(next);

				//�� or ���[�v�E�o
				strmorph::dic_t::idmap_value_t &iv(strmorph::dic.find(next));				
				if(!iv.ptr_data->compressed_transitionmap.data_length) break;
				strmorph::dic_t::data_t::transitionmap_t transitionmap(iv.ptr_data->compressed_transitionmap);
				next = transitionmap.data[gen() % transitionmap.length].dst_id;
				if(next == dic_t::data_t::transitionmap_t::nil) break;
			}

			if(next == dic_t::data_t::transitionmap_t::nil) return true;

			//�I�[�Ɍq������̂�D��I�ɑI��
			for(; ; ){
				if(fn::ttest(next)) break;

				dic_t::idmap_value_t &iv(dic.find(next));
				dic_t::data_t::transitionmap_t::compressed_iterator
					cit(iv.ptr_data->compressed_transitionmap);
				dic_t::data_t::transitionmap_t::compressed_iterator
					end = cit.end();

				if(cit.data_length() == 0) break;
				for(int i = 0, e = gen() % cit.data_length(); i < e; ++cit, ++i){
					if(cit == end) cit = cit.begin();
				}
				if(cit == end) cit = cit.begin();

				next = (*cit).dst_id;
				if(next == dic_t::data_t::transitionmap_t::nil) break;
				result.push_back(next);
			}
			
			return true;
		}

		//�R���X�g���N�^
		log_t(){}

		//�f�X�g���N�^
		~log_t(){
			for(
				std::deque<morph_sequence_t>::iterator it = morph_sequence.begin(), end = morph_sequence.end();
				it != end;
				++it
			){
				delete[] it->data;
			}
		}
	};

	log_t log;
}
