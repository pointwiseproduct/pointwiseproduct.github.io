inline int CreateID(){
	static int id = 0;
	int r = id;
	++id;
	return r;
}
