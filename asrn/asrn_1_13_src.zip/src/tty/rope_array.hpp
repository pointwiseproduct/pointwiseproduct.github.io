#ifndef __TTY_ROPE_ARRAY__
#define __TTY_ROPE_ARRAY__

#ifdef _MSC_VER
#pragma warning (disable:4345)
#endif // _MSC_VER

#include <tty/sss_zero.hpp>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <boost/type_traits.hpp>

namespace tty{
	template<typename T, unsigned int SegSize = 0x400 / sizeof(T)> class rope_array{
	public:
		typedef T value_type;
		typedef typename boost::add_const<value_type>::type const_value_type;
		typedef typename boost::add_reference<value_type>::type reference;
		typedef typename boost::add_reference<const_value_type>::type const_reference;
		typedef int size_type;

	private:
		typedef rope_array<T, SegSize> this_t;

	private:
		struct Seg{
			T data[SegSize];
		};

		typedef std::vector<Seg*> segptr_t;
		struct object_pool_t{
			void *malloc() const{
				return reinterpret_cast<void*>(new char[sizeof(Seg)]);
			}

			void free(void *ptr) const{
				delete[] reinterpret_cast<char*>(ptr);
			}
		};

		segptr_t segptr;
		object_pool_t object_pool;
		size_type size_;

	public:
		class const_iterator{
			friend this_t;
			friend class iterator;

			const this_t *ptr;
			size_type i;

			const_iterator(const this_t *ptr_) : ptr(ptr_), i(0){}

		public:
			const_iterator(const const_iterator &it) : ptr(it.ptr), i(it.i){}

			size_type index() const{
				return i;
			}

			const value_type &operator *() const{
				return ptr->segptr[i / SegSize]->data[i % SegSize];
			}

			const value_type &operator ->() const{
				return &**this;
			}

			const_iterator operator +(const const_iterator &rhs) const{
				const_iterator r(ptr);
				r.i = i + rhs.i;
				return r;
			}

			template<typename arithmetic_type>
			const_iterator operator +(arithmetic_type j) const{
				const_iterator r(ptr);
				r.i = i + static_cast<size_type>(j);
				return r;
			}

			const_iterator operator -(const const_iterator &rhs) const{
				const_iterator r(ptr);
				r.i = i - rhs.i;
				return r;
			}

			template<typename arithmetic_type>
			const_iterator operator -(arithmetic_type j) const{
				const_iterator r(ptr);
				r.i = i - static_cast<size_type>(j);
				return r;
			}

			const_iterator &operator ++(){
				++i;
				return *this;
			}

			const_iterator &operator --(){
				--i;
				return *this;
			}

			template<typename arithmetic_type>
			value_type &operator [](const arithmetic_type &i){
				return *(*this + i);
			}

			bool operator ==(const const_iterator &rhs) const{
				return ptr == rhs.ptr && i == rhs.i;
			}

			bool operator !=(const const_iterator &rhs) const{
				return ptr != rhs.ptr || i != rhs.i;
			}

			operator size_type() const{
				return i;
			}
		};

		class iterator : public const_iterator{
			friend this_t;

			iterator(this_t *ptr_) : const_iterator(ptr_){}

		public:
			iterator(const iterator &it) : const_iterator(it){}
			iterator(const const_iterator &it) : const_iterator(it){}

			size_type index() const{
				return i;
			}

			value_type &operator *(){
				return
					const_iterator::ptr->segptr[
						const_iterator::i / SegSize
					]->data[
						const_iterator::i % SegSize
					];
			}

			value_type &operator ->(){
				return &**this;
			}

			iterator operator +(const iterator &rhs) const{
				iterator r(ptr);
				r.i = i + rhs.i;
				return r;
			}

			template<typename arithmetic_type>
			iterator operator +(arithmetic_type j) const{
				iterator r(ptr);
				r.i = i + static_cast<size_type>(j);
				return r;
			}

			iterator operator -(const iterator &rhs) const{
				iterator r(ptr);
				r.i = i - rhs.i;
				return r;
			}

			template<typename arithmetic_type>
			iterator operator -(arithmetic_type j) const{
				iterator r(ptr);
				r.i = i - static_cast<size_type>(j);
				return r;
			}

			iterator &operator ++(){
				++const_iterator::i;
				return *this;
			}

			iterator &operator --(){
				--const_iterator::i;
				return *this;
			}

			template<typename arithmetic_type>
			value_type &operator [](const arithmetic_type &i){
				return *(*this + i);
			}

			bool operator ==(const iterator &rhs) const{
				return const_iterator::ptr == rhs.ptr && const_iterator::i == rhs.i;
			}

			bool operator !=(const iterator &rhs) const{
				return const_iterator::ptr != rhs.ptr || const_iterator::i != rhs.i;
			}

			operator size_type() const{
				return i;
			}
		};

	public:
		size_type size() const{
			return size_;
		}

		iterator begin(){
			return iterator(this);
		}

		iterator end(){
			iterator r = (this);
			r.i = this->size_;
			return r;
		}

		const_iterator begin() const{
			return const_iterator(this);
		}

		const_iterator end() const{
			const_iterator r = (this);
			r.i = this->size_;
			return r;
		}

		void push_back(const_reference a){
			if((size_ % SegSize) == 0){
				segptr.push_back(static_cast<Seg*>(object_pool.malloc()));
				new(segptr.back()->data) value_type(a);
			}else{
				new(&segptr.back()->data[size_ % SegSize]) value_type(a);
			}

			++size_;
		}

		void pop_back(){
			segptr.back()->data[size_ % SegSize].~value_type();
			--size_;
			if((size_ % SegSize) == 0){
				object_pool.free(segptr.back());
				segptr.pop_back();
			}
		}

		template<typename arithmetic_type>
		reference access(const arithmetic_type &i){
			return segptr[i / SegSize]->data[i % SegSize];
		}

		template<typename arithmetic_type>
		const_reference access(const arithmetic_type &i) const{
			return segptr[i / SegSize]->data[i % SegSize];
		}

		template<typename arithmetic_type>
		const_reference const_access(const arithmetic_type &i) const{
			return access(i);
		}

		reference at(const size_type &i){
			return access(i);
		}

		const_reference at(const size_type &i) const{
			return const_access(i);
		}

		reference front(){
			return access(size_ - 1);
		}

		const_reference front() const{
			return const_access(size_ - 1);
		}

		reference back(){
			return access(0);
		}

		const_reference back() const{
			return const_access(0);	
		}

		bool empty() const{
			return size_ == 0;
		}

		void clear(){
			for(int i = 0; i < size_; ++i){
				access(i).~value_type();
			}

			for(int i = 0, e = static_cast<int>(segptr.size()); i < e; ++i){
				delete[] reinterpret_cast<char*>(segptr[i]);
			}

			segptr.clear();
		}

		void erase(size_type n){
			access(n).~value_type();
			--size_;

			for(size_type i = n; i < size_; ++i){
				if(((i + 1) % SegSize) == 0){
					std::memcpy(
						reinterpret_cast<void*>(&segptr[i / SegSize]->data[i % SegSize]),
						reinterpret_cast<const void*>(&segptr[i / SegSize + 1]->data[0]),
						sizeof(value_type)
					);
				}else{
					int t = i / SegSize, u = i % SegSize;
					std::memcpy(
						reinterpret_cast<void*>(&segptr[t]->data[u]),
						reinterpret_cast<const void*>(&segptr[t]->data[u + 1]),
						sizeof(value_type)
					);
				}
			}

			if((size_ / SegSize) == 0){
				object_pool.free(segptr.back());
				segptr.pop_back();
			}
		}

		iterator erase(iterator it){
			erase(it.i);
			return it;
		}

		iterator erase(iterator it, iterator end){
			int num = end.i - it.i;

			for(int i = 0; i < num; ++i){
				access(i + it.i).~value_type();
			}

			int t, u, v = size_ - end.i;
			for(int i = 0; i < v; ++i){
				t = i + it.i, u = i + end.i;
				std::memcpy(
					reinterpret_cast<void*>(&segptr[t / SegSize]->data[t % SegSize]),
					reinterpret_cast<const void*>(&segptr[u / SegSize]->data[u % SegSize]),
					sizeof(value_type)
				);
			}

			for(int i = 0, e = num / SegSize + ((num % SegSize) ? 1 : 0); i < e; ++i){
				object_pool.free(segptr.back());
				segptr.pop_back();
			}

			size_ -= num;

			return it;
		}

		void resize(size_type nsize, const value_type &val = value_type()){
			size_type
				nseg = nsize / SegSize,
				oseg = size_ / SegSize,
				segdiff;

			if(nsize > size_){
				segdiff = nseg - oseg;
				segdiff += (nsize % SegSize ? 1 : 0) - (size_ % SegSize ? 1 : 0);

				for(int i = 0; i < segdiff; ++i){
					segptr.push_back(reinterpret_cast<Seg*>(object_pool.malloc()));
				}

				for(size_type i = size_; i < nsize; ++i){
					new(&segptr[i / SegSize]->data[i % SegSize]) value_type(val);
				}
			}else if(nsize < size_){
				segdiff = oseg - nseg;

				for(int i = nsize; i < size_; ++i){
					access(i).~value_type();
				}

				for(size_type i = 0; i < segdiff; ++i){
					object_pool.free(segptr.back());
					segptr.pop_back();
				}
			}

			size_ = nsize;
		}

		template<typename arithmetic_type>
		reference operator [](const arithmetic_type &i){
			return access(i);
		}

		template<typename arithmetic_type>
		const_reference operator [](const arithmetic_type &i) const{
			return const_access(i);
		}

		template<typename arithmetic_type>
		reference autoexpansible_get(const arithmetic_type &i){
			int t = i + 1;
			if(t > size_) resize(t);
			return access(i);
		}

		template<typename arithmetic_type>
		const_reference const_autoexpansible_get(const arithmetic_type &i) const{
			if(i > size_) resize(i + 1);
			return const_access(i);
		}

		template<typename arithmetic_type>
		reference aeg(const arithmetic_type &i){
			return autoexpansible_get(i);
		}

		template<typename arithmetic_type>
		reference const_aeg(const arithmetic_type &i) const{
			return const_autoexpansible_get(i);
		}

		rope_array() : size_(0){}

		rope_array(const rope_array &ob){
			size_type nseg = ob.size_ / SegSize;

			for(int i = 0; i < nseg; ++i){
				segptr.push_back(reinterpret_cast<Seg*>(object_pool.malloc()));
			}

			for(size_type i = size_; i < size_; ++i){
				new(&segptr[i / SegSize]->data[i % SegSize]) value_type(ob.access(i));
			}
		}

		virtual ~rope_array(){
			clear();
		}
	};
}

#ifdef _MSC_VER
#pragma warning (default:4345)
#endif // _MSC_VER

#endif // __TTY_ROPE_ARRAY__
