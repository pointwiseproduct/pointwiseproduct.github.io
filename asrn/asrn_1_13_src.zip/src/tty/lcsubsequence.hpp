#ifndef __TTY_LCS_SEQUENCE__
#define __TTY_LCS_SEQUENCE__

#include <cstring>

namespace tty{
	template<typename T, typename vt = int> class lcsubsequence{
		struct telm{
			vt value;
			enum dir_t{
				//�����Ȃ�
				//���ƘA��
				//��ƘA��
				//����ƘA��
				n = 0, l, u, lu
			}dir;
		};

		telm *table;
		int table_size;

	public:
		//�T�����ʂ̌^
		//POD�������ɂ���
		struct resultseq_t{
			int length;
			T *data;
			bool *chain;

			void destruction() const{
				delete[] data;
				delete[] chain;
			}

			resultseq_t copy() const{
				resultseq_t r;
				r.length = length;
				r.data = new T[length];
				r.chain = new bool[length];

				std::memcpy(
					reinterpret_cast<void*>(r.data),
					reinterpret_cast<const void*>(data),
					sizeof(int) * length
				);

				std::memcpy(
					reinterpret_cast<void*>(r.chain),
					reinterpret_cast<const void*>(chain),
					sizeof(bool) * length
				);

				return r;
			}

			bool operator ==(const resultseq_t &rhs) const{
				if(length == rhs.length){
					const int e = length;
					for(int i = 0; i < e; ++i){
						if((data[i] == rhs.data[i]) && (chain[i] == rhs.chain[i])) continue;
						return false;
					}

					return true;
				}else{
					return false;
				}
			}

			bool operator !=(const resultseq_t &rhs) const{
				if(length != rhs.length){
					const int e = length;
					for(int i = 0; i < e; ++i){
						if((data[i] != rhs.data[i]) && (chain[i] != rhs.chain[i])) continue;
						return false;
					}

					return true;
				}else{
					return false;
				}
			}

			bool operator <(const resultseq_t &rhs) const{
				if(length == rhs.length){
					const int e = length;
					for(int i = 0; i < e; ++i){
						if(data[i] == rhs.data[i]){
							/**/
						}else{
							return data[i] < rhs.data[i];
						}

						if(chain[i] == rhs.chain[i]){
							continue;
						}else{
							return chain[i] < rhs.chain[i];
						}
					}

					return false;
				}else{
					return length < rhs.length;
				}
			}

			bool operator <=(const resultseq_t &rhs) const{
				if(length == rhs.length){
					const int e = length;
					for(int i = 0; i < e; ++i){
						if(data[i] == rhs.data[i]){
							/**/
						}else{
							return data[i] < rhs.data[i];
						}

						if(chain[i] == rhs.chain[i]){
							continue;
						}else{
							return chain[i] < rhs.chain[i];
						}
					}

					return true;
				}else{
					return length < rhs.length;
				}
			}

			bool operator >(const resultseq_t &rhs) const{
				if(length == rhs.length){
					const int e = length;
					for(int i = 0; i < e; ++i){
						if(data[i] == rhs.data[i]){
							/**/
						}else{
							return data[i] > rhs.data[i];
						}

						if(chain[i] == rhs.chain[i]){
							continue;
						}else{
							return chain[i] > rhs.chain[i];
						}
					}

					return false;
				}else{
					return length > rhs.length;
				}
			}

			bool operator >=(const resultseq_t &rhs) const{
				if(length == rhs.length){
					const int e = length;
					for(int i = 0; i < e; ++i){
						if(data[i] == rhs.data[i]){
							/**/
						}else{
							return data[i] > rhs.data[i];
						}

						if(chain[i] == rhs.chain[i]){
							continue;
						}else{
							return chain[i] > rhs.chain[i];
						}
					}

					return true;
				}else{
					return length > rhs.length;
				}
			}
		};

		class resultseq_holder : public resultseq_t{
			resultseq_holder(){}
			void operator =(const resultseq_t&){}

			T *data;
			bool *chain;
			int length;

		public:
			const T *get_data() const{ return data; }
			const bool *get_chain() const{ return chain; }
			int get_length() const{ return length; }

			resultseq_holder(const resultseq_t &a) : data(a.data), chain(a.chain), length(a.length){}

			resultseq_holder &operator =(const resultseq_holder &a){
				delete[] data;
				delete[] chain;
				data = new T[a.length];
				chain = new bool[a.length];
				std::memcpy(data, a.data, sizeof(T) * a.length);
				std::memcpy(chain, a.chain, sizeof(bool) * a.length);
				length = a.length;
				return *this;
			}

			resultseq_holder(const resultseq_holder &a){
				data = new T[a.length];
				chain = new bool[a.length];
				std::memcpy(data, a.data, sizeof(T) * a.length);
				std::memcpy(chain, a.chain, sizeof(bool) * a.length);
				length = a.length;
				return *this;
			}

			~resultseq_holder(){
				delete[] data;
				delete[] chain;
			}
		};

		int get_tablesize() const{ return table_size; }

		void reserve(int a){
			if(tablesize == a) return;
			delete[] table;
			table = new telm[a];
			tablesize = a;
		}

		//�T��
		resultseq_t search(const T *s_a, int size_a, const T *s_b, int size_b){
			int usefulrange = (size_a + 1) * (size_b + 1);

			//�e�[�u���T�C�Y�̃`�F�b�N
			if(usefulrange > table_size){
				delete[] table;
				table = new telm[usefulrange];
				table_size = usefulrange;
			}

			//�e�[�u���̏�����
			std::memset(
				reinterpret_cast<void*>(table),
				0,
				static_cast<size_t>(usefulrange * sizeof(telm))
			);

			//�e�[�u�����\������
			for(int i = 1; i <= size_a; ++i){
				for(int j = 1; j <= size_b; ++j){
					int t = (size_b + 1) * i + j;
					if(s_b[j - 1] == s_a[i - 1]){
						table[t].value = table[(size_b + 1) * (i - 1) + (j - 1)].value + 1;
						table[t].dir = telm::lu;
					}else{
						int
							t0 = table[(size_b + 1) * (i - 1) + j].value,
							t1 = table[(size_b + 1) * i + (j - 1)].value;
						if(t0 >= t1){
							table[t].value = t0;
							table[t].dir = telm::u;
						}else{
							table[t].value = t1;
							table[t].dir = telm::l;
						}
					}
				}
			}

			//�����𑪂�
			//�����ł͓�x��������
			int length = 0;
			{
				int i = size_a, j = size_b;
				for(; i && j; ){
					telm::dir_t t = table[(size_b + 1) * i + j].dir;
					if(t == telm::lu){
						--i, --j;
						++length;
					}else if(t == telm::u){ --i; }else{ --j; }
				}
			}

			resultseq_t r;
			r.data = new T[length];
			r.length = length;
			r.chain = new bool[length];

			{
				int i = size_a, j = size_b;
				int cnt = length;

				for(; cnt > 0; ){
					telm::dir_t t = table[(size_b + 1) * i + j].dir;
					if(t == telm::lu){
						//if(cnt != r.length)
						//	r.chain[length - 1] = s_a[i] == s_b[j] && s_a[i] == r.data[cnt];
						//�Ƃ����������@���s���œK������₷�����ȁH
						r.chain[cnt - 1] = cnt != r.length && s_a[i] == s_b[j] && s_a[i] == r.data[cnt];

						r.data[cnt - 1] = s_a[i - 1];
						--cnt, --i, --j;
					}else if(t == telm::u){ --i; }else{ --j; }
				}
			}

			return r;
		}

		resultseq_t operator ()(const T *s_a, int size_a, const T *s_b, int size_b){
			return search(s_a, size_a, s_b, size_b);
		}

		lcsubsequence &operator =(const lcsubsequence&){
			return *this;
		}

		lcsubsequence() : table(NULL), table_size(0){}
		lcsubsequence(const lcsubsequence&) : table(NULL), table_size(0){}
		virtual ~lcsubsequence(){
			delete[] table;
		}
	};
}

#endif // __TTY_LCS_SEQUENCE__
