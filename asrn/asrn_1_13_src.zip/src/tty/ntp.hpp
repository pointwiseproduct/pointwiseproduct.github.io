#ifndef __TTY_NTP__
#define __TTY_NTP__

#include <boost/preprocessor.hpp>

#define NTP_TUPLE_ARGTYPE(num, i, tuple) \
	BOOST_PP_TUPLE_ELEM(2, 0, BOOST_PP_TUPLE_ELEM(num, i, tuple))

#define NTP_TUPLE_ARGNAME(num, i, tuple) \
	BOOST_PP_TUPLE_ELEM(2, 1, BOOST_PP_TUPLE_ELEM(num, i, tuple))

// ���[�U�[��`�̈�����
#define NTP_CLASS_WRITEARG_0_I(r, nil, i, tuple) \
	BOOST_PP_COMMA_IF(i) \
	BOOST_PP_TUPLE_ELEM(2, 0, tuple) \
	BOOST_PP_TUPLE_ELEM(2, 1, tuple)

#define NTP_CLASS_WRITEARG_0(seq) \
	BOOST_PP_SEQ_FOR_EACH_I(NTP_CLASS_WRITEARG_0_I, nil, seq)

#define NTP_ARG_WRITEARG_0_I(r, nil, i, tuple) \
	BOOST_PP_COMMA_IF(i) BOOST_PP_TUPLE_ELEM(2, 1, tuple)

#define NTP_ARG_WRITEARG_0(seq) \
	BOOST_PP_SEQ_FOR_EACH_I(NTP_ARG_WRITEARG_0_I, nil, seq)

// ��������A�ԂŋL�q���� 1
// targ_n
#define NTP_CLASS_WRITEARG_1_I(r, nil, i, tuple) \
	BOOST_PP_COMMA_IF(i) \
	BOOST_PP_TUPLE_ELEM(2, 0, tuple) \
	BOOST_PP_CAT(targ_, i)

#define NTP_CLASS_WRITEARG_1(seq) \
	BOOST_PP_SEQ_FOR_EACH_I(NTP_CLASS_WRITEARG_1_I, nil, seq)

#define NTP_ARG_WRITEARG_1_I(r, nil, i, tuple) \
	BOOST_PP_COMMA_IF(i) BOOST_PP_CAT(targ_, i)

#define NTP_ARG_WRITEARG_1(seq) \
	BOOST_PP_SEQ_FOR_EACH_I(NTP_ARG_WRITEARG_1_I, nil, seq)

// ��������A�ԂŋL�q���� 2
// targ_n_
#define NTP_CLASS_WRITEARG_2_I(r, nil, i, tuple) \
	BOOST_PP_COMMA_IF(i) \
	BOOST_PP_TUPLE_ELEM(2, 0, tuple) \
	BOOST_PP_CAT(BOOST_PP_CAT(targ_, i), _)

#define NTP_CLASS_WRITEARG_2(seq) \
	BOOST_PP_SEQ_FOR_EACH_I(NTP_CLASS_WRITEARG_2_I, nil, seq)

#define NTP_ARG_WRITEARG_2_I(r, nil, i, tuple) \
	BOOST_PP_COMMA_IF(i) BOOST_PP_CAT(BOOST_PP_CAT(targ_, i), _)

#define NTP_ARG_WRITEARG_2(seq) \
	BOOST_PP_SEQ_FOR_EACH_I(NTP_ARG_WRITEARG_2_I, nil, seq)

//
#define NTP_ARGSTRUCT_III() _

#define NTP_ARGSTRUCT_II(i, spi) \
	BOOST_PP_IIF(BOOST_PP_EQUAL(i, spi), NTP_ARGSTRUCT_III, BOOST_PP_EMPTY)()

#define NTP_ARGSTRUCT_I(z, i, spi) \
	BOOST_PP_COMMA_IF(i) \
	BOOST_PP_CAT(BOOST_PP_CAT(targ_, i), NTP_ARGSTRUCT_II(i, spi))

#define NTP_ARGSTRUCT(r, seq, i, tuple) \
	template< \
		BOOST_PP_TUPLE_ELEM(2, 0, tuple) \
		BOOST_PP_CAT(BOOST_PP_CAT(targ_, i), _) \
	> struct BOOST_PP_TUPLE_ELEM(2, 1, tuple) : \
		dg<BOOST_PP_REPEAT(BOOST_PP_SEQ_SIZE(seq), NTP_ARGSTRUCT_I, i)>{};

#define NTP_THIS_TYPE_HOLDER(name) \
	BOOST_PP_CAT(this_t_holder_, BOOST_PP_CAT(name, __))

#define NTP_THIS_TYPE(name) \
	BOOST_PP_CAT(BOOST_PP_CAT(_, name), _this_t__)

#define NTP_REDECDG(name) \
	BOOST_PP_CAT(BOOST_PP_CAT(_, name), _recdg__)

#define NTP_REDEC__(name) \
	BOOST_PP_CAT(BOOST_PP_CAT(_, name), _redec__)

#define NTP_HEAD(dec, name, seq) \
	template<NTP_CLASS_WRITEARG_0(seq)> dec name; \
	template<NTP_CLASS_WRITEARG_1(seq)> struct NTP_THIS_TYPE_HOLDER(name) \
	{ typedef name<NTP_ARG_WRITEARG_1(seq)> NTP_THIS_TYPE(name); }; \
	template<NTP_CLASS_WRITEARG_1(seq)> struct NTP_REDECDG(name){ \
		template<NTP_CLASS_WRITEARG_2(seq)> struct holder \
		{ typedef name<NTP_ARG_WRITEARG_2(seq)> end; }; \
		template<NTP_CLASS_WRITEARG_2(seq)> struct dg : \
			holder<NTP_ARG_WRITEARG_2(seq)>, \
			NTP_REDECDG(name)<NTP_ARG_WRITEARG_2(seq)>{}; \
		BOOST_PP_SEQ_FOR_EACH_I(NTP_ARGSTRUCT, seq, seq) \
	};\
	template<typename T> struct BOOST_PP_CAT(BOOST_PP_CAT(_, name), _redec__); \
	template<NTP_CLASS_WRITEARG_1(seq)> \
	struct NTP_REDEC__(name)< name<NTP_ARG_WRITEARG_1(seq)> > : \
		BOOST_PP_CAT(BOOST_PP_CAT(_, name), _recdg__)<NTP_ARG_WRITEARG_1(seq)>{};

#define NTP_DEC(dec, name, seq) \
	template<NTP_CLASS_WRITEARG_0(seq)> dec name : \
		public NTP_THIS_TYPE_HOLDER(name)<NTP_ARG_WRITEARG_0(seq)>

#define TTY_NTP(dec, name, seq) \
	NTP_HEAD(dec, name, seq) NTP_DEC(dec, name, seq)

#define TTY_NTP_REDEC(target, type) NTP_REDEC__(target)<type::NTP_THIS_TYPE(target)>

#endif // __TTY_NTP__
