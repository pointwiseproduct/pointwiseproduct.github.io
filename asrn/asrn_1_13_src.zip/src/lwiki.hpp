#include <string>
#include <vector>
#include <set>
#include <algorithm>
#include <cstring>
#include <tty/quick_search.hpp>
#include <boost/preprocessor/repeat.hpp>
#include <boost/preprocessor/punctuation/comma_if.hpp>
#include <tty/st.hpp>
#include <tty/setlocale_japanese.hpp>

namespace strmorph{
	//wikipedia���w�K
	void lwiki_a(){
		typedef std::map<std::string, int> category_t;
		category_t category;
		std::deque<std::string> scanned;
#define asdf(a) category.insert(category_t::value_type(std::string(a), 1));
asdf("http://ja.wikipedia.org/wiki/Category:%E6%96%B9%E6%B3%95%E8%AB%96") asdf("http://ja.wikipedia.org/wiki/Category:%E7%90%86%E8%AB%96%E8%A8%88%E7%AE%97%E6%A9%9F%E7%A7%91%E5%AD%A6") asdf("http://ja.wikipedia.org/wiki/Category:%E6%96%87%E5%AD%A6%E7%90%86%E8%AB%96") asdf("http://ja.wikipedia.org/wiki/Category:%E7%9B%B8%E5%AF%BE%E6%80%A7%E7%90%86%E8%AB%96") asdf("http://ja.wikipedia.org/wiki/Category:%E9%9F%B3%E6%A5%BD%E7%90%86%E8%AB%96") asdf("http://ja.wikipedia.org/wiki/Category:%E3%82%B0%E3%83%A9%E3%83%95%E7%90%86%E8%AB%96") asdf("http://ja.wikipedia.org/wiki/Category:%E8%A8%88%E7%AE%97%E7%90%86%E8%AB%96") asdf("http://ja.wikipedia.org/wiki/Category:%E8%A8%80%E8%AA%9E%E5%AD%A6") asdf("http://ja.wikipedia.org/wiki/Category:%E9%9F%B3%E6%A5%BD%E5%AD%A6") asdf("http://ja.wikipedia.org/wiki/Category:%E7%90%86%E8%AB%96") asdf("http://ja.wikipedia.org/wiki/Category:%E6%B3%95%E5%89%87") asdf("http://ja.wikipedia.org/wiki/Category:%E6%95%B0%E7%90%86%E7%A7%91%E5%AD%A6") asdf("http://ja.wikipedia.org/wiki/Category:%E4%BA%BA%E6%96%87%E7%A7%91%E5%AD%A6") asdf("http://ja.wikipedia.org/wiki/Category:%E7%A4%BE%E4%BC%9A%E7%A7%91%E5%AD%A6") asdf("http://ja.wikipedia.org/wiki/Category:%E8%87%AA%E7%84%B6%E7%A7%91%E5%AD%A6") asdf("http://ja.wikipedia.org/wiki/Category:%E8%AB%96%E7%90%86%E5%AD%A6") asdf("http://ja.wikipedia.org/wiki/Category:%E6%96%87%E5%AD%A6") asdf("http://ja.wikipedia.org/wiki/Category:%E6%95%B0%E5%AD%A6%E3%81%AB%E9%96%A2%E3%81%99%E3%82%8B%E8%A8%98%E4%BA%8B") asdf("http://ja.wikipedia.org/wiki/Category:%E6%95%B0%E5%AD%A6") asdf("http://ja.wikipedia.org/wiki/Category:%E5%BF%83%E7%90%86%E5%AD%A6") asdf("http://ja.wikipedia.org/wiki/Category:%E5%B7%A5%E5%AD%A6") asdf("http://ja.wikipedia.org/wiki/Category:%E5%8C%96%E5%AD%A6") asdf("http://ja.wikipedia.org/wiki/Category:%E5%8C%BB%E5%AD%A6") asdf("http://ja.wikipedia.org/wiki/Category:%E3%83%9E%E3%83%BC%E3%82%AF%E3%82%A2%E3%83%83%E3%83%97%E8%A8%80%E8%AA%9E") asdf("http://ja.wikipedia.org/wiki/Category:%E3%83%97%E3%83%AD%E3%82%B0%E3%83%A9%E3%83%9F%E3%83%B3%E3%82%B0%E8%A8%80%E8%AA%9E") asdf("http://ja.wikipedia.org/wiki/Category:%E3%83%8F%E3%83%BC%E3%83%89%E3%82%A6%E3%82%A7%E3%82%A2%E8%A8%98%E8%BF%B0%E8%A8%80%E8%AA%9E") asdf("http://ja.wikipedia.org/wiki/Category:%E7%B5%B1%E4%B8%80%E3%83%A2%E3%83%87%E3%83%AA%E3%83%B3%E3%82%B0%E8%A8%80%E8%AA%9E") asdf("http://ja.wikipedia.org/wiki/Category:%E5%95%8F%E3%81%84%E5%90%88%E3%82%8F%E3%81%9B%E8%A8%80%E8%AA%9E") asdf("http://ja.wikipedia.org/wiki/Category:%E3%82%B9%E3%82%BF%E3%82%A4%E3%83%AB%E3%82%B7%E3%83%BC%E3%83%88%E8%A8%80%E8%AA%9E") asdf("http://ja.wikipedia.org/wiki/Category:%E6%95%B0%E5%BC%8F%E5%87%A6%E7%90%86%E3%82%B7%E3%82%B9%E3%83%86%E3%83%A0") asdf("http://ja.wikipedia.org/wiki/Category:%E3%83%97%E3%83%AD%E3%82%B0%E3%83%A9%E3%83%9F%E3%83%B3%E3%82%B0") asdf("http://ja.wikipedia.org/wiki/Category:%E3%82%B3%E3%83%B3%E3%83%94%E3%83%A5%E3%83%BC%E3%82%BF%E8%A8%80%E8%AA%9E") asdf("http://ja.wikipedia.org/wiki/Category:%E8%A8%88%E7%AE%97%E6%A9%9F%E7%A7%91%E5%AD%A6") asdf("http://ja.wikipedia.org/wiki/Category:%E6%94%BE%E9%80%81") asdf("http://ja.wikipedia.org/wiki/Category:%E5%85%B5%E5%99%A8") asdf("http://ja.wikipedia.org/wiki/Category:%E3%83%90%E3%82%A4%E3%82%AA%E3%83%86%E3%82%AF%E3%83%8E%E3%83%AD%E3%82%B8%E3%83%BC") asdf("http://ja.wikipedia.org/wiki/Category:%E5%8B%95%E5%8A%9B") asdf("http://ja.wikipedia.org/wiki/Category:%E9%81%93%E5%85%B7") asdf("http://ja.wikipedia.org/wiki/Category:%E9%9B%BB%E6%B0%97") asdf("http://ja.wikipedia.org/wiki/Category:%E9%9B%BB%E6%B0%97") asdf("http://ja.wikipedia.org/wiki/Category:%E9%80%9A%E4%BF%A1") asdf("http://ja.wikipedia.org/wiki/Category:%E3%82%B3%E3%83%B3%E3%83%94%E3%83%A5%E3%83%BC%E3%82%BF") asdf("http://ja.wikipedia.org/wiki/Category:%E4%BA%A4%E9%80%9A") asdf("http://ja.wikipedia.org/wiki/Category:%E5%BB%BA%E8%A8%AD") asdf("http://ja.wikipedia.org/wiki/Category:%E7%89%A9%E8%B3%AA") asdf("http://ja.wikipedia.org/wiki/Category:%E7%89%A9%E8%B3%AA") asdf("http://ja.wikipedia.org/wiki/Category:%E5%85%89")  asdf("http://ja.wikipedia.org/wiki/Category:%E7%86%B1") asdf("http://ja.wikipedia.org/wiki/Category:%E5%A4%A9%E4%BD%93") asdf("http://ja.wikipedia.org/wiki/Category:%E5%9C%B0%E7%90%83") asdf("http://ja.wikipedia.org/wiki/Category:%E5%9C%B0%E7%90%83") asdf("http://ja.wikipedia.org/wiki/Category:%E7%94%9F%E7%89%A9") asdf("http://ja.wikipedia.org/wiki/Category:%E6%A3%AE%E6%9E%97") asdf("http://ja.wikipedia.org/wiki/Category:%E5%85%83%E7%B4%A0") asdf("http://ja.wikipedia.org/wiki/Category:%E6%B0%97%E8%B1%A1") asdf("http://ja.wikipedia.org/wiki/Category:%E7%92%B0%E5%A2%83") asdf("http://ja.wikipedia.org/wiki/Category:%E9%9F%B3") asdf("http://ja.wikipedia.org/wiki/Category:%E3%82%A8%E3%83%8D%E3%83%AB%E3%82%AE%E3%83%BC") asdf("http://ja.wikipedia.org/wiki/Category:%E8%A1%8C%E6%94%BF") asdf("http://ja.wikipedia.org/wiki/Category:%E8%A1%8C%E6%94%BF") asdf("http://ja.wikipedia.org/wiki/Category:%E6%B3%95") asdf("http://ja.wikipedia.org/wiki/Category:%E7%A6%8F%E7%A5%89") asdf("http://ja.wikipedia.org/wiki/Category:%E6%88%A6%E4%BA%89") asdf("http://ja.wikipedia.org/wiki/Category:%E6%94%BF%E6%B2%BB") asdf("http://ja.wikipedia.org/wiki/Category:%E7%A4%BE%E4%BC%9A%E5%95%8F%E9%A1%8C") asdf("http://ja.wikipedia.org/wiki/Category:%E6%A0%BC%E5%B7%AE%E7%A4%BE%E4%BC%9A") asdf("http://ja.wikipedia.org/wiki/Category:%E7%A4%BE%E4%BC%9A%E5%AD%A6") asdf("http://ja.wikipedia.org/wiki/Category:%E6%80%9D%E6%83%B3") asdf("http://ja.wikipedia.org/wiki/Category:%E5%9B%BD%E9%9A%9B%E9%96%A2%E4%BF%82") asdf("http://ja.wikipedia.org/wiki/Category:%E7%B5%8C%E6%B8%88") asdf("http://ja.wikipedia.org/wiki/Category:%E6%95%99%E8%82%B2") asdf("http://ja.wikipedia.org/wiki/Category:%E6%97%A5%E6%9C%AC%E3%81%AE%E5%85%83%E5%8F%B7") asdf("http://ja.wikipedia.org/wiki/Category:%E6%97%A5%E6%9C%AC%E3%81%AE%E8%BB%8D%E4%BA%8B") asdf("http://ja.wikipedia.org/wiki/Category:%E6%97%A5%E6%9C%AC%E3%81%AE%E7%B4%80%E5%B9%B4%E6%B3%95") asdf("http://ja.wikipedia.org/wiki/Category:%E6%97%A5%E6%9C%AC%E3%81%AE%E8%A6%B3%E5%85%89%E5%9C%B0_%28%E8%87%AA%E7%84%B6%29") asdf("http://ja.wikipedia.org/wiki/Category:%E6%97%A5%E6%9C%AC%E3%81%AE%E7%A5%9E") asdf("http://ja.wikipedia.org/wiki/Category:%E6%97%A5%E6%9C%AC%E5%AD%A6%E8%80%85") asdf("http://ja.wikipedia.org/wiki/Category:%E6%97%A5%E6%9C%AC%E3%81%AE%E7%A7%91%E5%AD%A6%E6%8A%80%E8%A1%93") asdf("http://ja.wikipedia.org/wiki/Category:%E6%97%A5%E6%9C%AC") asdf("http://ja.wikipedia.org/wiki/Category:%E3%83%A8%E3%83%BC%E3%83%AD%E3%83%83%E3%83%91") asdf("http://ja.wikipedia.org/wiki/Category:%E4%B8%AD%E6%9D%B1") asdf("http://ja.wikipedia.org/wiki/Category:%E3%82%AA%E3%82%BB%E3%82%A2%E3%83%8B%E3%82%A2") asdf("http://ja.wikipedia.org/wiki/Category:%E3%82%A2%E3%83%A1%E3%83%AA%E3%82%AB") asdf("http://ja.wikipedia.org/wiki/Category:%E3%82%A2%E3%83%95%E3%83%AA%E3%82%AB") asdf("http://ja.wikipedia.org/wiki/Category:%E3%82%A2%E3%82%B8%E3%82%A2") asdf("http://ja.wikipedia.org/wiki/Category:%E5%9C%B0%E7%90%86%E5%AD%A6") asdf("http://ja.wikipedia.org/wiki/Category:%E5%9C%B0%E5%BD%A2") asdf("http://ja.wikipedia.org/wiki/Category:%E5%A4%A7%E9%99%B8") asdf("http://ja.wikipedia.org/wiki/Category:%E6%BC%AB%E7%94%BB") asdf("http://ja.wikipedia.org/wiki/Category:%E7%BE%8E%E8%A1%93") asdf("http://ja.wikipedia.org/wiki/Category:%E3%82%B9%E3%83%9D%E3%83%BC%E3%83%84") asdf("http://ja.wikipedia.org/wiki/Category:%E9%A3%9F%E6%96%87%E5%8C%96") asdf("http://ja.wikipedia.org/wiki/Category:%E5%9C%B0%E5%9F%9F%E5%8F%B2") asdf("http://ja.wikipedia.org/wiki/Category:%E5%90%84%E5%9B%BD%E3%81%AE%E4%BA%8B%E4%BB%B6") asdf("http://ja.wikipedia.org/wiki/Category:%E6%97%A5%E6%9C%AC%E3%81%AE%E6%88%A6%E4%BA%89") asdf("http://ja.wikipedia.org/wiki/Category:%E3%82%A2%E3%82%B8%E3%82%A2%E5%8F%B2") asdf("http://ja.wikipedia.org/wiki/Category:%E3%82%A2%E3%83%95%E3%83%AA%E3%82%AB%E5%8F%B2") asdf("http://ja.wikipedia.org/wiki/Category:%E3%82%A2%E3%83%A1%E3%83%AA%E3%82%AB%E5%A4%A7%E9%99%B8%E5%8F%B2") asdf("http://ja.wikipedia.org/wiki/Category:%E3%82%AA%E3%82%BB%E3%82%A2%E3%83%8B%E3%82%A2%E5%8F%B2") asdf("http://ja.wikipedia.org/wiki/Category:%E3%83%A8%E3%83%BC%E3%83%AD%E3%83%83%E3%83%91%E5%8F%B2") asdf("http://ja.wikipedia.org/wiki/Category:%E3%83%89%E3%82%A4%E3%83%84%E3%81%AE%E6%AD%B4%E5%8F%B2") asdf("http://ja.wikipedia.org/wiki/Category:%E3%83%89%E3%82%A4%E3%83%84%E5%8F%B2%E3%81%AE%E4%BA%BA%E7%89%A9") asdf("http://ja.wikipedia.org/wiki/Category:%E3%83%86%E3%83%BC%E3%83%9E%E5%8F%B2") asdf("http://ja.wikipedia.org/wiki/Category:%E3%82%B3%E3%83%B3%E3%83%94%E3%83%A5%E3%83%BC%E3%82%BF%E5%8F%B2") asdf("http://ja.wikipedia.org/wiki/Category:%E7%A7%91%E5%AD%A6%E5%8F%B2") asdf("http://ja.wikipedia.org/wiki/Category:%E6%8A%80%E8%A1%93%E5%8F%B2") asdf("http://ja.wikipedia.org/wiki/Category:%E6%83%85%E5%A0%B1%E6%8A%80%E8%A1%93%E5%8F%B2") asdf("http://ja.wikipedia.org/wiki/Category:%E6%94%BF%E6%B2%BB%E5%8F%B2") asdf("http://ja.wikipedia.org/wiki/Category:%E4%B8%96%E4%BB%A3") asdf("http://ja.wikipedia.org/wiki/Category:%E7%BE%8E%E8%A1%93%E5%8F%B2") asdf("http://ja.wikipedia.org/wiki/Category:%E4%BA%BA%E3%81%AE%E4%B8%80%E7%94%9F") asdf("http://ja.wikipedia.org/wiki/Category:%E3%83%9E%E3%82%B9%E3%83%A1%E3%83%87%E3%82%A3%E3%82%A2%E3%81%AE%E6%AD%B4%E5%8F%B2") asdf("http://ja.wikipedia.org/wiki/Category:%E6%97%A5%E6%9C%AC%E3%81%AE%E6%97%A7%E5%9B%BD%E5%90%8D") asdf("http://ja.wikipedia.org/wiki/Category:%E6%97%A5%E6%9C%AC%E3%81%AE%E6%97%A7%E5%9C%B0%E5%9F%9F%E5%90%8D") asdf("http://ja.wikipedia.org/wiki/Category:%E3%82%B3%E3%83%B3%E3%83%94%E3%83%A5%E3%83%BC%E3%82%BF%E3%81%AB%E9%96%A2%E3%81%99%E3%82%8B%E6%B3%95%E5%89%87") asdf("http://ja.wikipedia.org/wiki/Category:%E3%82%B3%E3%83%B3%E3%83%94%E3%83%A5%E3%83%BC%E3%82%BF%E9%96%A2%E9%80%A3%E4%BA%BA%E7%89%A9") asdf("http://ja.wikipedia.org/wiki/Category:%E3%82%B3%E3%83%B3%E3%83%94%E3%83%A5%E3%83%BC%E3%82%BF_%28%E6%AD%B4%E4%BB%A3%29") asdf("http://ja.wikipedia.org/wiki/Category:21%E4%B8%96%E7%B4%80%E3%81%AE%E6%95%B0%E5%AD%A6%E8%80%85") asdf("http://ja.wikipedia.org/wiki/Category:%E5%AE%87%E5%AE%99%E9%96%8B%E7%99%BA") asdf("http://ja.wikipedia.org/wiki/Category:%E6%97%A5%E6%9C%AC%E7%BE%8E%E8%A1%93%E5%8F%B2") asdf("http://ja.wikipedia.org/wiki/Category:%E4%BA%94%E7%95%BF%E5%85%AB%E9%81%93") asdf("http://ja.wikipedia.org/wiki/Category:%E6%99%82%E4%BB%A3%E5%8C%BA%E5%88%86") asdf("http://ja.wikipedia.org/wiki/Category:%E5%85%88%E5%8F%B2%E6%99%82%E4%BB%A3") asdf("http://ja.wikipedia.org/wiki/Category:%E5%85%83%E5%8F%B7") asdf("http://ja.wikipedia.org/wiki/Category:%E7%AF%80%E6%B0%97") asdf("http://ja.wikipedia.org/wiki/Category:%E6%9B%9C%E6%97%A5") asdf("http://ja.wikipedia.org/wiki/Category:%E6%9A%A6%E6%B3%A8") asdf("http://ja.wikipedia.org/wiki/Category:%E8%A8%98%E5%BF%B5%E6%97%A5") asdf("http://ja.wikipedia.org/wiki/Category:%E7%B4%80%E5%B9%B4%E6%B3%95") asdf("http://ja.wikipedia.org/wiki/Category:%E5%AD%A3%E7%AF%80") asdf("http://ja.wikipedia.org/wiki/Category:%E3%82%A2%E3%83%8B%E3%83%A1") asdf("http://ja.wikipedia.org/wiki/Category:%E9%9F%B3%E6%A5%BD") asdf("http://ja.wikipedia.org/wiki/Category:%E8%8A%B8%E8%A1%93") asdf("http://ja.wikipedia.org/wiki/Category:%E3%82%B2%E3%83%BC%E3%83%A0")
#undef asdf

		struct mark_t{
			const wchar_t *str;
			int length;
			mark_t(const wchar_t *str_) : str(str_), length(tty::ta_length(str_)){}
		};

		//�ڈ�
		mark_t
			subcategory_class(L"CategoryTreeLabel  CategoryTreeLabelNs14 CategoryTreeLabelCategory"),
			tow_mark(L"</div><div id=\"mw-pages\">"),
			tow_endmark(L"</tr></table>");

		tty::quick_search<wchar_t> xsearch;
		tty::quick_search<char> urlsearch;
		std::vector<char> buff;
		std::deque<wchar_t> str;
		std::deque<dic_t::data_t*> linked_dvec;
		std::string http_ja_wikipedia_org("http://ja.wikipedia.org"), straddr;
		wchar_t *ptr_buff;
		int filesize, elemnum;
		category_t::iterator it;

		//�L���ւ̃����N�������ꂽ�t�@�C��
		tty::wfstream linkf(L"wikilink.txt", std::ios::out);

#define asdf(s) \
	const char *sslist[] = { BOOST_PP_REPEAT(BOOST_PP_SEQ_SIZE(s), asdf_i, s) }; \
	const int sslist_strlength[] = { BOOST_PP_REPEAT(BOOST_PP_SEQ_SIZE(s), asdf_ii, s) }; \
	const int sslist_length = sizeof(sslist_strlength) / sizeof(*sslist_strlength);
#define asdf_i(z, i, s) BOOST_PP_SEQ_ELEM(i, s),
#define asdf_ii(z, i, s) tty::ta_length(BOOST_PP_SEQ_ELEM(i, s)),
		asdf(
			("%E3%83%A6%E3%83%BC%E3%82%B6%E3%83%BC")("%E3%82%B9%E3%82%BF%E3%83%96")("user")("User")
		);
#undef asdf
#undef asdf_i
#undef asdf_ii

		struct fn{
			inline static void strft(std::string &testfile, int num, int page = 0){
				testfile.assign("test.txt");
			}

			inline static void fileread(std::vector<char> &buff, wchar_t* &ptr_buff, int &filesize, int &elemnum, int lognum, int pnum){
				std::fstream file;

				std::string testfile;
				strft(testfile, lognum, pnum);

				file.open(testfile.c_str(), std::ios::in | std::ios::binary);
				file.seekg(0, std::fstream::end);
				filesize = static_cast<int>(file.tellg()); file.seekg(0);

				if(buff.capacity() < static_cast<unsigned int>(filesize))
					buff.reserve(filesize);
				buff.resize(filesize);
				file.read(&buff[0], filesize);

				ptr_buff = reinterpret_cast<wchar_t*>(&buff[0]);
				elemnum = filesize / sizeof(wchar_t);
			}
		};

		for(int mst_counter = 0; category.size() != 0; ++mst_counter){
			//�y�[�W�f�[�^���擾����
			{
				it = category.begin();
				std::string testfile;
				fn::strft(testfile, mst_counter);
				std::string addr(std::string("sladin.exe ") + it->first + std::string(" ") + testfile);
				std::cout
					<< "  " << category.size() << "/" << mst_counter << " : " << it->second << std::endl
					<< it->first << std::endl;
				std::system(addr.c_str());
			}

			//���[�h
			fn::fileread(buff, ptr_buff, filesize, elemnum, mst_counter, 0);

			int find = 0, add = 0;			
			for(int cnt = 0; ; ++cnt){
				std::cout << "  p" << cnt << std::endl;
				linked_dvec.clear();

				//�P���T��
				xsearch.preprocess(tow_mark.str, tow_mark.length);
				int tow_start = xsearch(ptr_buff, elemnum) + tow_mark.length;
				xsearch.preprocess(tow_endmark.str, tow_endmark.length);
				int tow_end = xsearch(&ptr_buff[tow_start], elemnum - tow_start) + tow_start + tow_endmark.length;

				xsearch.preprocess(tow_mark.str, tow_mark.length);

				for(
					tow_start = xsearch(&ptr_buff[tow_start], elemnum - tow_start) + tow_start + tow_mark.length;
					tow_start < tow_end;
					tow_start = xsearch(&ptr_buff[tow_start], elemnum - tow_start) + tow_start + tow_mark.length
				){
					++find;

					static const mark_t url_start(L"href=\""), word_start(L"title=\"");
					//�����N�������
					xsearch.preprocess(url_start.str, url_start.length);
					int link_start = xsearch(&ptr_buff[tow_start], elemnum - tow_start) + tow_start + url_start.length;
					int link_length = tty::ta_length(&ptr_buff[link_start], L'"');
					linkf << std::wstring(&ptr_buff[link_start], link_length) << std::endl;

					//�����������
					xsearch.preprocess(word_start.str, word_start.length);
					int str_start = xsearch(&ptr_buff[tow_start], elemnum - tow_start) + tow_start + word_start.length;

					//�������T���Ď����ɓ����
					//���{
					if(!tty::ta_index(&ptr_buff[str_start], L':', L'"') && !tty::ta_index(&ptr_buff[str_start], L'(', L'"')){
						int str_length = tty::ta_length(&ptr_buff[str_start], L'"');
						dic_t::insert_result_t insert_result = dic.insert(&ptr_buff[str_start], str_length);

						//����������̏����Ȃǂ�
						const dic_t::key_t &k(insert_result.first->first);
						dic_t::data_t &d(insert_result.first->second);
						if(insert_result.second) ++add;

						//connectionmap�ɒǉ��Ȃ�
						dic_t::data_t::connectionmap_t connectionmap_v(d.compressed_connectionmap);
						for(int i = 0, e = static_cast<int>(linked_dvec.size()); i < e; ++i){
							dic_t::data_t::connectionmap_t connectionmap_w(linked_dvec[i]->compressed_connectionmap);
							connectionmap_w.insert(d.id);
							//delete[] linked_dvec[i]->compressed_connectionmap.data;
							//linked_dvec[i]->compressed_connectionmap.data = connectionmap_w.encode(
							//	linked_dvec[i]->compressed_connectionmap.data_length
							//);
							connectionmap_w.encode(linked_dvec[i]->compressed_connectionmap);

							connectionmap_v.insert(linked_dvec[i]->id);
						}
						if(linked_dvec.size()){
							//delete[] d.compressed_connectionmap.data;
							//d.compressed_connectionmap.data = connectionmap_v.encode(
							//	d.compressed_connectionmap.data_length
							//);
							connectionmap_v.encode(d.compressed_connectionmap);
						}
						linked_dvec.push_back(&d);
					}
				}

				//�T�u�J�e�S����T��
				//if((it->second > 0) && (cnt == 0) && (add > 0)){
				//	xsearch.preprocess(subcategory_class.str, subcategory_class.length);
				//	int search_result = 0, prev_result = 0;
				//	for(
				//		search_result = xsearch(&ptr_buff[search_result], elemnum - search_result) + search_result + subcategory_class.length;
				//		search_result != prev_result + subcategory_class.length - 1;
				//		prev_result = search_result, search_result = xsearch(&ptr_buff[search_result], elemnum - search_result) + search_result + subcategory_class.length
				//	){
				//		//�A�h���X�����ޕ�����
				//		static const wchar_t *addr_start = L"href=\"";
				//		static const int addr_start_length = tty::ta_length(addr_start);

				//		//����
				//		xsearch.preprocess(addr_start, addr_start_length);
				//		int str_start
				//			= xsearch(
				//				&ptr_buff[search_result],
				//				elemnum - search_result
				//			) + search_result + addr_start_length;

				//		//�T�u�J�e�S����ǉ�
				//		straddr.clear();
				//		waddr2caddr(straddr, &ptr_buff[str_start]);
				//		//�T���ς݂łȂ�������
				//		std::string tmpstr = http_ja_wikipedia_org + straddr;
				//		std::deque<std::string>::iterator tit = std::find(scanned.begin(), scanned.end(), tmpstr);
				//		if(tit == scanned.end())
				//			category.insert(category_t::value_type(tmpstr, it->second - 1));

				//		xsearch.preprocess(subcategory_class.str, subcategory_class.length);
				//	}
				//}

				//����T��
				static const mark_t nextentry_mark(L") (<a href=\""), printfooter_mark(L"<div class=\"printfooter\">");
				xsearch.preprocess(nextentry_mark.str, nextentry_mark.length);
				int nextentry;
				int nextentry_0 = xsearch(&ptr_buff[tow_end], elemnum - tow_end) + tow_end + nextentry_mark.length;
				int nextentry_1 = xsearch(&ptr_buff[nextentry_0], elemnum - nextentry_0);
				if(nextentry_1 == -1){
					nextentry = nextentry_0;
				}else{
					nextentry = nextentry_1 + nextentry_0 + nextentry_mark.length;
				}
				xsearch.preprocess(printfooter_mark.str, printfooter_mark.length);
				int printfooter = xsearch(&ptr_buff[tow_end], elemnum - tow_end) + tow_end + printfooter_mark.length;
				if((nextentry < printfooter) && (nextentry > (tow_end + nextentry_mark.length))){
					//�y�[�W�f�[�^�擾
					straddr.clear();
					waddr2caddr(straddr, &ptr_buff[nextentry]);

					{
						std::string testfile;
						fn::strft(testfile, mst_counter, cnt + 1);
						std::string asdfstr((
							std::string("sladin.exe ") +
							http_ja_wikipedia_org +
							straddr +
							std::string(" ") +
							testfile
						).c_str());
						std::system(asdfstr.c_str());
					}

					//���[�h
					fn::fileread(buff, ptr_buff, filesize, elemnum, mst_counter, cnt + 1);
					continue;
				}else{
					std::cout << add << "/" << find << std::endl;
					if((add == 0) && (find != 0)){
						//
						scanned.push_back(it->first);
					}
					category.erase(it);
					break;
				}
			}

			std::cout << std::endl;
		}
	}

	//�L�����w�K
	void lwiki_b(){
		struct fn{
			inline static void fileread(std::vector<char> &buff, wchar_t* &ptr_buff, int &filesize, int &elem_num){
				std::fstream file;

				file.open("test.txt", std::ios::in | std::ios::binary);
				file.seekg(0, std::fstream::end);
				filesize = static_cast<int>(file.tellg()); file.seekg(0);

				if(buff.capacity() < static_cast<unsigned int>(filesize))
					buff.reserve(filesize);
				buff.resize(filesize);
				file.read(&buff[0], filesize);

				ptr_buff = reinterpret_cast<wchar_t*>(&buff[0]);
				elem_num = filesize / sizeof(wchar_t);
			}
		};

		struct mark_t{
			const wchar_t *str;
			int length;
			mark_t(const wchar_t *str_) : str(str_), length(tty::ta_length(str_)){}
		};

		mark_t
			str_start_content(L"<!-- start content -->"),
			str_start_content_p(L"<p>"),
			str_start_content_endp(L"</p>"),
			str_end_content(L"<!-- end content -->");

		tty::quick_search<wchar_t> xsearch;
		std::fstream linkf("wikilink.txt", std::ios::in);
		std::string addrstr, http_ja_wikipedia_org = "http://ja.wikipedia.org";
		int mst_cnt = 0;
		std::vector<char> buff;
		wchar_t *ptr_buff;
		int filesize;
		int elem_num;
		int strcnt = 0;
		wchar_t tmp = 0;
		std::wstring str;

		for(linkf >> addrstr; !linkf.fail(); ++mst_cnt, linkf >> addrstr){
			if(mst_cnt % 4) continue;
			if((addrstr[0] != '/') || (addrstr[5] != '/')) continue;
			std::cout << addrstr << std::endl;
			while(
				std::system(
					(std::string("sladin.exe ") + http_ja_wikipedia_org + addrstr + std::string(" test.txt")).c_str()
				)
			);
			fn::fileread(buff, ptr_buff, filesize, elem_num);//���[�h			
			int localcnt = 0;

			//�e��C���f�b�N�X�̒l�𓾂�
			xsearch.preprocess(str_start_content.str, str_start_content.length);
			const int start_content = xsearch(ptr_buff, elem_num) + str_start_content.length;
			if(start_content == -1) continue;
			xsearch.preprocess(str_end_content.str, str_end_content.length);
			const int end_content = xsearch(ptr_buff, elem_num) + str_end_content.length;

			for(int i = 0; ; ){
				//start_content_p�̏�����
				xsearch.preprocess(str_start_content_p.str, str_start_content_p.length);
				const int start_content_p =
					xsearch(
						ptr_buff + start_content + i,
						elem_num - (start_content + i)
					) + str_start_content_p.length + start_content + i;

				//�I������
				if(
					(
						start_content_p
						== (str_start_content_p.length + start_content + i - 1)
					) || (
						start_content_p > end_content
					)
				){
					break;
				}

				i = start_content_p;

				//start_content_endp�̏�����
				xsearch.preprocess(str_start_content_endp.str, str_start_content_endp.length);
				const int start_content_endp =
					xsearch(
						ptr_buff + start_content_p,
						elem_num - start_content_p
					) + start_content_p;

				//�����������A��������
				for(; i < start_content_endp; ++i){
					//�^�O�𖳎�����
					if(ptr_buff[i] == L'<'){
						struct{
							int operator()(const wchar_t *str, int i){
								int cnt = 0;
								for(++i; ; ++i){
									if(str[i] == L'<') ++cnt;
									if(str[i] == L'>')
										if(cnt > 0)
											--cnt;
										else
											break;
								}
								return i;
							}
						}avoid_tag;

						i = avoid_tag(ptr_buff, i);
						continue;
					}

					//�^�u�A���s��u������
					if(ptr_buff[i] == L'\t' || ptr_buff[i] == L'\n'){
						ptr_buff[i] = L' ';
					}					

					//��؂肪�o���Ƃ���ŉ�͂�����
					if(
						(buff[i] == L'�I') ||
						(buff[i] == L'!') ||
						(buff[i] == L'�H') ||
						(buff[i] == L'?') ||
						(buff[i] == L'�B') ||
						(buff[i] == L'�A') ||
						(buff[i] == L'�D') ||
						(buff[i] == L'�C') ||
						(ptr_buff[i] == L'.' && (tmp < L'0' || tmp > L'9') && tmp != L'/')  ||
						(ptr_buff[i] == L' ' && ((tmp < L'a' || tmp > L'z') || (tmp < L'A' || tmp > L'Z')) && (tmp != L'�B' && tmp != L'�D' && tmp != L'.')) ||
						(ptr_buff[i] == L'�@') ||
						(false)
					){
						str += ptr_buff[i];
						if(str.size() >= 2){
							std::wcout
								<< mst_cnt << L":"
								<< strcnt << L":"
								<< localcnt << std::endl;

							log.in(str.c_str());
						}

						++strcnt; ++localcnt;
						str.clear();
						tmp = 0;
						continue;
					}

					str += ptr_buff[i];
					tmp = ptr_buff[i];
				}
			}
		}
	}
}
