#include <tty/st.hpp>
#include <boost/preprocessor/stringize.hpp>

namespace strmorph{
	//�������e��ۑ�����t�@�C���̃p�X
	struct{
		class holder_t{
			const char *char_str_;
			const wchar_t *wchar_str_;

		public:
			inline const char *char_str() const{
				return char_str_;
			}

			inline operator const char *() const{
				return char_str_;
			}

			inline const wchar_t *wchar_str() const{
				return wchar_str_;
			}

			inline operator const wchar_t *() const{
				return wchar_str_;
			}

			holder_t() : char_str_(NULL), wchar_str_(NULL){}

			holder_t(const char *c, const wchar_t *wc) :
				char_str_(c),
				wchar_str_(wc)
			{}
		};

#define asdf(a) \
holder_t( \
	BOOST_PP_STRINGIZE(a), \
	TTY_WSTRINGIZE(a) \
)
		holder_t dic() const{ return asdf(data/dic.data); }
		holder_t hdid() const{ return asdf(data/hdid.data); }
		holder_t idiom_hdid() const{ return asdf(data/idiom_hdid.data); }
		holder_t idiomdic() const{ return asdf(data/idiomdic.data); }
		holder_t log() const{ return asdf(data/log.data); }
#undef asdf
	}datafilepath;
}